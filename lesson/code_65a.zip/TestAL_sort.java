import java.util.ArrayList;
import java.util.List;
import java.util.Arrays;
import java.util.Comparator;

public class TestAL_sort {

// public void sort(Comparator<? super E> c)
// java.util.Comparator<T> 是函數介面, 指向形如 int compare(T o1,T o2) 的函數. 


   static int cmpY(XY v1, XY v2) {
      // if(v1.y<v2.y) return -1;
      // else if(v1.y==v2.y) return 0;
      // else return 1;
      return (v1.y<v2.y) ? -1 : (v1.y==v2.y) ? 0 : 1 ;  // right associativity
      // return (int)(Math.signum(v1-v2));
   }

   static void test1() {
      System.out.println("\n --- test1: by method reference  ----");

      XY[] b1= { new XY(0.0f,6.2f),  new XY(2.0f,5.2f), 
                 new XY(4.0f,4.2f),  new XY(4.0f,3.2f) };
      ArrayList<XY> AL1= new ArrayList<XY>(List.of(b1)); 
      System.out.println("AL1: "+AL1);
      System.out.println("b1:  "+Arrays.toString(b1));

   // AL1.sort(Test_sortObjA_cmptor::compareY);
      AL1.sort(TestAL_sort::cmpY);
      System.out.println("after compareY,\nAL1: "+AL1);
      System.out.println("b1:  "+Arrays.toString(b1));

      AL1.sort(Test_sortObjA_cmptor::compareX);
      System.out.println("after compareX,\nAL1: "+AL1);
      System.out.println("b1:  "+Arrays.toString(b1));
   }
/*
 --- test1: by method reference  ----
AL1: [(0.0,6.2), (2.0,5.2), (4.0,4.2), (4.0,3.2)]
b1:  [(0.0,6.2), (2.0,5.2), (4.0,4.2), (4.0,3.2)]
after compareY,
AL1: [(4.0,3.2), (4.0,4.2), (2.0,5.2), (0.0,6.2)]
b1:  [(0.0,6.2), (2.0,5.2), (4.0,4.2), (4.0,3.2)]
after compareX,
AL1: [(0.0,6.2), (2.0,5.2), (4.0,3.2), (4.0,4.2)]      ******
b1:  [(0.0,6.2), (2.0,5.2), (4.0,4.2), (4.0,3.2)]
*/

   static void test2() {
      System.out.println("\n --- test2: by lambda expression ----");

      ArrayList<Float> AL1= 
         new ArrayList<Float>(List.of(0.7f, 0.2f, 0.3f, 0.9f, 0.1f)); 
      System.out.println("AL1: "+AL1);

      AL1.sort( (x, y)->(x<y)? -1 : ((float)x==(float)y)? 0: 1  );
      System.out.println("after sort,\nAL1: "+AL1);
   }
/*
 --- test2: by lambda expression ----
AL1: [0.7, 0.2, 0.3, 0.9, 0.1]
after sort,
AL1: [0.1, 0.2, 0.3, 0.7, 0.9]
*/

   static void test3() {
      System.out.println("\n --- test3: natural order ----");

      ArrayList<Float> AL1= 
         new ArrayList<Float>(List.of(0.7f, 0.2f, 0.3f, 0.9f, 0.1f)); 
      System.out.println("AL1: "+AL1);

   // AL1.sort( null );  // less reabable
   // java.util.Collections.sort(AL1);  // older tool
      AL1.sort( java.util.Comparator.naturalOrder() );
      System.out.println("after sorted by naturalOrder,\nAL1: "+AL1);

      AL1.sort( java.util.Comparator.reverseOrder() );
      System.out.println("after sorted by reverseOrder(),\nAL1: "+AL1);
   }
/*
 --- test3: natural order ----
AL1: [0.7, 0.2, 0.3, 0.9, 0.1]
after sorted by naturalOrder,
AL1: [0.1, 0.2, 0.3, 0.7, 0.9]
after sorted by reverseOrder(),
AL1: [0.9, 0.7, 0.3, 0.2, 0.1]
*/

   static void test4() {
      System.out.println("\n --- test4: compare with null ----");

      ArrayList<Float> AL1;
      try {
         AL1= new ArrayList<Float>(  
                 List.of(0.7f, 0.2f, 0.3f, null, 0.9f, 0.1f)
              );
      }
      catch(java.lang.NullPointerException xpt) {
         System.out.println("catch NullPointerException on ctor"); 
      } 
      AL1= new ArrayList<Float>();
      {
         AL1.add(0.7f);  AL1.add(0.2f);  AL1.add(0.3f);
         AL1.add(null);  AL1.add(0.9f);  AL1.add(0.1f);
      }
      System.out.println("AL1: "+AL1);
      try { 
         AL1.sort( java.util.Comparator.naturalOrder() ); 
      }
      catch(java.lang.NullPointerException xpt) {
         System.out.println("catch NullPointerException on sort"); 
      } 
      AL1.sort( Comparator.nullsFirst(Comparator.naturalOrder()) ); // cause .NullPointerException
      System.out.println("after sorted by nullsFirst,\nAL1: "+AL1);

      AL1.sort( Comparator.nullsLast(Comparator.naturalOrder()) ); // cause .NullPointerException
      System.out.println("after sorted by nullsLast,\nAL1: "+AL1);
   }
/*
 --- test4: compare with null ----
catch NullPointerException on ctor
AL1: [0.7, 0.2, 0.3, null, 0.9, 0.1]
catch NullPointerException on sort
after sorted by nullsFirst,
AL1: [null, 0.1, 0.2, 0.3, 0.7, 0.9]
after sorted by nullsLast,
AL1: [0.1, 0.2, 0.3, 0.7, 0.9, null]
*/

   static void test5() {
      System.out.println("\n --- test5: sort a portion ----");
   // move to TestAL_subList   
   }

   public static void main(String[] dummy){
      test1();
      test2();
      test3();
      test4();
   // test5();
      System.out.println("\n all OK" ); 

   }

}
