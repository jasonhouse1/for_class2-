import java.util.Arrays;
import java.util.ArrayList;
import java.util.List;


// Test clone()
public class TestAL_clone {


// in class java.util.ArrayList, 
//   public Object clone()
  static void test1() {
      System.out.println("\n --- test1: clone ----");
      String[] A0= { "aaa", "", "cc", "d", "ee" };
   // ArrayList<String> AL1= 
      var AL1= 
         new ArrayList<String>(List.of(A0));
      System.out.println("AL1: "+AL1+" ( "+AL1.getClass()+" ) ");

      @SuppressWarnings("unchecked") 
   // ArrayList<String> AL2= 
      var AL2= 
         (ArrayList<String>)AL1.clone(); 
      System.out.println("AL2: "+AL2+" ( "+AL2.getClass()+" ) ");

   // ArrayList<String> AL3= 
      var AL3= 
         new ArrayList<String>(AL1); 
      System.out.println("AL3: "+AL3+" ( "+AL3.getClass()+" ) ");
   }
/*
 --- test1: clone  ----
AL1: [aaa, , cc, d, ee] ( class java.util.ArrayList )
AL2: [aaa, , cc, d, ee] ( class java.util.ArrayList )
AL3: [aaa, , cc, d, ee] ( class java.util.ArrayList )
*/

  static void test2() {
      System.out.println("\n --- test2: shallow copy ----");
      ArrayList<Wrap_f> AL1= 
         new ArrayList<Wrap_f>(
            List.of(
                new Wrap_f(10.1f), new Wrap_f(10.2f), new Wrap_f(10.3f)
            )
         );
      System.out.println("AL1: "+AL1+" ( "+AL1.getClass()+" ) ");

      @SuppressWarnings("unchecked") 
      ArrayList<Wrap_f> AL2= (ArrayList<Wrap_f>)AL1.clone(); 
      System.out.println("AL2: "+AL2+" ( "+AL2.getClass()+" ) ");

      AL2.set(1, new Wrap_f(20));
      System.out.println("... after AL2.set(1, new Wrap_f(20)); "); 
      System.out.println("AL1: "+AL1+" ( "+AL1.getClass()+" ) ");
      System.out.println("AL2: "+AL2+" ( "+AL2.getClass()+" ) ");

      AL2.get(0).v+=3;
      AL2.get(1).v+=5;
      System.out.println("... after AL2.get(0).v+=3; AL2.get(1).v+=5; "); 
      System.out.println("AL1: "+AL1+" ( "+AL1.getClass()+" ) ");
      System.out.println("AL2: "+AL2+" ( "+AL2.getClass()+" ) ");
      System.out.println();
   }
/*
 --- test2: shallow copy ----
AL1: [10.1, 10.2, 10.3] ( class java.util.ArrayList )
AL2: [10.1, 10.2, 10.3] ( class java.util.ArrayList )
... after AL2.set(1, new Wrap_f(20));
AL1: [10.1, 10.2, 10.3] ( class java.util.ArrayList )
AL2: [10.1, 20.0, 10.3] ( class java.util.ArrayList )
... after AL2.get(0).v+=3; AL2.get(1).v+=5;
AL1: [13.1, 10.2, 10.3] ( class java.util.ArrayList )
AL2: [13.1, 25.0, 10.3] ( class java.util.ArrayList )
*/

  static void test3() {
      System.out.println("\n --- test3: deep copy ----");
      ArrayList<Wrap_f> AL1= 
         new ArrayList<Wrap_f>(
            List.of(
                new Wrap_f(10.1f), new Wrap_f(10.2f), new Wrap_f(10.3f)
            )
         );
      System.out.println("AL1: "+AL1+" ( "+AL1.getClass()+" ) ");

      ArrayList<Wrap_f> AL2= new ArrayList<Wrap_f>();
      for(int i=0; i<AL1.size(); i++) {
         AL2.add(new Wrap_f(AL1.get(i).v)); 
      // AL2.add(AL1.get(i).clone()); //: only if Wrap_f supports public clone()
      }
      System.out.println("AL2: "+AL2+" ( "+AL2.getClass()+" ) ");

      AL2.set(1, new Wrap_f(20));
      System.out.println("... after AL2.set(1, new Wrap_f(20)); "); 
      System.out.println("AL1: "+AL1+" ( "+AL1.getClass()+" ) ");
      System.out.println("AL2: "+AL2+" ( "+AL2.getClass()+" ) ");

      AL2.get(0).v+=3;
      AL2.get(1).v+=5;
      System.out.println("... after AL2.get(0).v+=3; AL2.get(1).v+=5; "); 
      System.out.println("AL1: "+AL1+" ( "+AL1.getClass()+" ) ");
      System.out.println("AL2: "+AL2+" ( "+AL2.getClass()+" ) ");
      System.out.println();
   }
/*
 --- test3: deep copy ----
AL1: [10.1, 10.2, 10.3] ( class java.util.ArrayList )
AL2: [10.1, 10.2, 10.3] ( class java.util.ArrayList )
... after AL2.set(1, new Wrap_f(20));
AL1: [10.1, 10.2, 10.3] ( class java.util.ArrayList )
AL2: [10.1, 20.0, 10.3] ( class java.util.ArrayList )
... after AL2.get(0).v+=3; AL2.get(1).v+=5;
AL1: [10.1, 10.2, 10.3] ( class java.util.ArrayList )
AL2: [13.1, 25.0, 10.3] ( class java.util.ArrayList )
*/

   public static void main(String[] dummy) {
      test1();
      test2();
      test3();
   }

}
