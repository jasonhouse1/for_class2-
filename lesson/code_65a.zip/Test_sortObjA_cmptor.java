import java.util.Arrays;
// use class XY

/*
@FunctionalInterface interface Comparator<T> {
   public int compareTo(T o1, T o2);
// ...
}
public static <T> void sort(T[] a, Comparator<? super T> c)
public static <T> void sort(T[] a, int fr, int to,
                            Comparator<? super T> c)
public static <T> int binarySearch(T[] a,  T key,
                                   Comparator<? super T> c)
public static <T> int binarySearch(T[] a, int fr, int to,
                                   T key,
                                   Comparator<? super T> c)
*/ 
class Test_sortObjA_cmptor {

 //[  Comparator<XY>  -------------------
   static int compareX(XY v1, XY v2) {
      if(v1.x<v2.x) return -1;
      else if(v1.x==v2.x) return 0;
      else return 1; 
   }
   static int compareY(XY v1, XY v2) {
      // return (v1.y-v2.y);  // possible lossy conversion from float to int
      if(v1.y<v2.y) return -1;
      else if(v1.y==v2.y) return 0;
      else return 1;
   }
   static int compareS(XY v1, XY v2) {
      float s1=v1.x+v1.y, s2=v2.x+v2.y;
      if(s1<s2) return -1;
      else if(s1==s2) return 0;
      else return 1;
   }
 //]  Comparator<XY>  -------------------

   static void test_ptr_sort() {
      System.out.println("\n --- test_ptr_sort ---");  

      XY[] b1= { new XY(0.0f,6.2f),  new XY(2.0f,5.2f), 
                 new XY(4.0f,4.2f),  new XY(8.0f,3.2f) };
      System.out.println("begin,\n b1: "+Arrays.toString(b1));

      try{ 
      Arrays.sort(b1); 
      }
      catch(java.lang.ClassCastException xpt) {
         System.out.println("... catched:  \n"+xpt);
      }

  //  Arrays.<XY>sort(b1, Test_sortObjA_cmptor::compareX); 
                                      // explicitly use XY for T
      Arrays.sort(b1, Test_sortObjA_cmptor::compareX);     
                                      // implicitly use XY for T
      System.out.println("after compareX,\n b1: "+Arrays.toString(b1));

      Arrays.sort(b1, Test_sortObjA_cmptor::compareY); 
                                      // implicitly use XY for T
      System.out.println("after compareY,\n b1: "+Arrays.toString(b1));

      Arrays.sort(b1, Test_sortObjA_cmptor::compareS); 
                                      // implicitly use XY for T 
      System.out.println("after compareS,\n b1: "+Arrays.toString(b1));

   }
/*
 --- test_ptr_sort ---
begin,
 b1: [(0.0,6.2), (2.0,5.2), (4.0,4.2), (8.0,3.2)]
... catched:
java.lang.ClassCastException: class XY cannot be cast to class java.lang.Comparable (XY is in unnamed module of loader 'app'; java.lang.Comparable is in module java.base of loader 'bootstrap')
after compareX,
 b1: [(0.0,6.2), (2.0,5.2), (4.0,4.2), (8.0,3.2)]
after compareY,
 b1: [(8.0,3.2), (4.0,4.2), (2.0,5.2), (0.0,6.2)]
after compareS,
 b1: [(0.0,6.2), (2.0,5.2), (4.0,4.2), (8.0,3.2)]
*/

  // test  public static int binarySearch(Object[] a, Object key)
  // test  public static int binarySearch(Object[] a, int from, int to, Object key)
  // test  public static <T> int binarySearch(T[] a, T key, 
  //                                Comparator<? super T> c)
  // test  public static <T> int binarySearch(T[] a, int fromIndex, int toIndex, T key, 
  //                                Comparator<? super T> c)
  static void test_ptr_binarySearch() {
      System.out.println("\n --- test_ptr_binarySearch ---");  

      XY[] b1= { new XY(0.0f,6.2f),  new XY(2.0f,5.2f), 
                 new XY(4.0f,4.2f),  new XY(6.0f,3.2f) };
      System.out.println("b1: "+Arrays.toString(b1));  

      Arrays.sort(b1, Test_sortObjA_cmptor::compareY); 
      System.out.println("after compareY,\n b1: "+Arrays.toString(b1));

      XY v1= new XY(3.0f, 4.2f);
      System.out.println(
         "binarySearch "+ v1+" by Test_Sort::compareY: "
         +Arrays.binarySearch(b1, v1, Test_sortObjA_cmptor::compareY)
      );

      XY v2= new XY(2.0f, 3.2f);
      System.out.println(
         "binarySearch "+ v2+" by Test_Sort::compareY: "
         +Arrays.binarySearch(b1, v2, Test_sortObjA_cmptor::compareY)
      );

      XY v3= new XY(2.0f, 5.0f);
      System.out.println(
         "binarySearch "+ v3+" by Test_Sort::compareY: "
         +Arrays.binarySearch(b1, v3, Test_sortObjA_cmptor::compareY)
      );

   }
/*
 --- test_ptr_binarySearch ---
b1: [(0.0,6.2), (2.0,5.2), (4.0,4.2), (6.0,3.2)]
after compareY,
 b1: [(6.0,3.2), (4.0,4.2), (2.0,5.2), (0.0,6.2)]
binarySearch (3.0,4.2) by Test_Sort::compareY: 1
binarySearch (2.0,3.2) by Test_Sort::compareY: 0
binarySearch (2.0,5.0) by Test_Sort::compareY: -3
*/

   public static void main(String[] dummy) {

      test_ptr_sort();

      test_ptr_binarySearch();
      System.out.println("\nall OK");

   }

}

