import java.util.Arrays;
import java.util.ArrayList;
import java.util.List;


// Test Array FromTo
public class TestAL_trans {

  static void test1() {
      System.out.println("\n --- test1: Array to ArrayList  ----");
      String[] A0= { "aaa", "", "cc", "d", "ee" };
      System.out.println("A0: "+Arrays.toString(A0)
                         +" ( "+A0.getClass()+" ) ");
      ArrayList<String> AL1= 
         new ArrayList<String>(List.of(A0));
      System.out.println("AL1: "+AL1+" ( "+AL1.getClass()+" ) ");

   } 
/*
 --- test1: Array to ArrayList  ----
A0: [aaa, , cc, d, ee] ( class [Ljava.lang.String; )
AL1: [aaa, , cc, d, ee] ( class java.util.ArrayList )
*/


  static void test2() {
      System.out.println("\n --- test2: ArrayList to Array  ----");
      String[] A0= { "aaa", "", "cc", "d", "ee" };
      System.out.println("A0: "+Arrays.toString(A0)
                          +" ( "+A0.getClass()+" ) ");
      ArrayList<String> AL1= new ArrayList<String>();
      for(int i=0; i<A0.length; i++) {
         AL1.add(A0[i]);
      }  
      System.out.println("AL1: "+AL1+" ( "+ AL1.getClass()+" ) ");

      String[] A1= new String[AL1.size()];
      AL1.<String>toArray(A1); 
   // AL1.toArray(A1); 
      System.out.println("A1: "+Arrays.toString(A1)
                           +" ( "+A1.getClass()+" ) ");
  }
/*
 --- test2: ArrayList to Array  ----
A0: [aaa, , cc, d, ee] ( class [Ljava.lang.String; )
AL1: [aaa, , cc, d, ee] ( class java.util.ArrayList )
A1: [aaa, , cc, d, ee] ( class [Ljava.lang.String; )
*/

  static void test2_bad() {
      System.out.println("\n --- test2_bad: ArrayList to Array  ----");
      String[] A0= { "aaa", "", "cc", "d", "ee" };
      System.out.println("A0: "+Arrays.toString(A0)
                         +" ( "+A0.getClass()+" ) ");
      ArrayList<String> AL1= new ArrayList<String>();
      for(int i=0; i<A0.length; i++) {
         AL1.add(A0[i]);
      }  
      System.out.println("AL1: "+AL1+" ( "+ AL1.getClass() +" ) ");

      Object[] A5= AL1.toArray();
      System.out.println("A5: "+Arrays.toString(A5)
                         +" ( "+A5.getClass()+" ) ");
      String[] A6;
      try{
         A6= (String[])A5;
      }
      catch(java.lang.ClassCastException xpt) {
         System.out.println("catch: "+xpt); 
      }  
/*  
    in java.util.Arrays
    public static 
    <T,U> T[] copyOf(U[] original, int newLen,
                     Class<? extends T[]> newType)
*/
      A6= 
      // Arrays.<String,Object>copyOf(A5, A5.length, String[].class);
         Arrays.copyOf(A5, A5.length, String[].class);
      System.out.println("A6: "+Arrays.toString(A6)
                         +" ( "+A6.getClass()+" ) ");
   } 
/*
 --- test2_bad: ArrayList to Array  ----
A0: [aaa, , cc, d, ee] ( class [Ljava.lang.String; )
AL1: [aaa, , cc, d, ee] ( class java.util.ArrayList )
A5: [aaa, , cc, d, ee] ( class [Ljava.lang.Object; )
catch: java.lang.ClassCastException: 
       class [Ljava.lang.Object; cannot be cast to class [Ljava.lang.String; ([Ljava.lang.Object; and [Ljava.lang.String; are in module java.base of loader 'bootstrap')
A6: [aaa, , cc, d, ee] ( class [Ljava.lang.String; )
*/



   public static void main(String[] dummy) {
      test1();
      test2();
      test2_bad();
   }

}
