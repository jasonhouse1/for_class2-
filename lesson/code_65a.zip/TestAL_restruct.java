import java.util.List;
import java.util.ArrayList;
import java.util.function.Predicate;

// structure test
public class TestAL_restruct {

// public boolean add(E e)
// public void add(int idx, E elm)  must 0<=idx<=this.size()
// public boolean addAll(Collection<? extends E> c)
// public boolean addAll(int idx, Collection<? extends E> c)
   static void test1() {
      System.out.println("\n --- test1: add, addAll  ----");
      var L= List.of("aaa", "b", "cc");  // return type: List<String>
      var AL1= new ArrayList<String>(); // return type: ArrayList<String>
      AL1.addAll(L);
      System.out.println(AL1);
      try{
         AL1.add(4, "Z1");
      } catch(java.lang.IndexOutOfBoundsException xpt) {
         System.out.println("catch: "+xpt); 
      } 
      AL1.add("Z1");
      System.out.println(AL1);
      AL1.add(1, "Z2");
      System.out.println(AL1);
      AL1.addAll(2, List.of("Z3", "Z4", "Z5"));
      System.out.println(AL1);
   } 
/*
 --- test1: add, addAll  ----
[aaa, b, cc]
catch: java.lang.IndexOutOfBoundsException: Index: 4, Size: 3
[aaa, b, cc, Z1]
[aaa, Z2, b, cc, Z1]
[aaa, Z2, Z3, Z4, Z5, b, cc, Z1]
*/

//-------------------------------------------------
// public void clear()
// public E remove(int index),  must 0 <= idx < this.size()
   static void test2() {
      System.out.println("\n --- test2: clear, remove(int)  ----");
      var L= List.<Float>of(10f, 11f, 12f, 13f, 14f);
      var AL1= new ArrayList<Float>(L);
      System.out.println("begin: "+AL1);
      Float elm= AL1.remove(0);
      System.out.println("after remove(0): "+AL1);
      System.out.println("removed element: "+elm);
   try{ 
      Float elm1= AL1.remove(5);
   }
   catch(IndexOutOfBoundsException xpt) {
      System.out.println("catch: "+xpt); 
   }
      AL1.clear();
      System.out.println("after clear(): "+AL1);
      System.out.println("isEmpty: "+AL1.isEmpty());
   }
/*
 --- test2: clear, remove(int)  ----
begin: [10.0, 11.0, 12.0, 13.0, 14.0]
after remove(0): [11.0, 12.0, 13.0, 14.0]
catch: java.lang.IndexOutOfBoundsException: 
       Index 5 out of bounds for length 4
after clear(): []
isEmpty: true
*/

//-------------------------------------------------
// protected void removeRange(int fromIdx, int toIdx)
// public List<E> subList(int fromIdx, int toIdx) 
//     Returns a view of the portion of this list 
   static void test2A() {
      System.out.println("\n --- test2A  ----");
      var L= List.<Float>of(10f, 11f, 12f, 13f, 14f);
      var AL1= new ArrayList<Float>(L);
      System.out.println("begin: "+AL1);
//    AL1.removeRange(1,3); // ERR: protected access
      List<Float> r= AL1.subList(1,3); // a view of AL1
      System.out.println("r, AL1.subList(1,3): "+r
                             +"("+r.getClass()+")");
      r.clear();
      System.out.println("after r.clear(): "+AL1);
   }
/*
 --- test2A  ----
begin: [10.0, 11.0, 12.0, 13.0, 14.0]
r, AL1.subList(1,3): [11.0, 12.0](class java.util.ArrayList$SubList)
after r.clear(): [10.0, 13.0, 14.0]
*/


//-------------------------------------------------
// public boolean remove(Object o)
//     Return true if this list contained the specified element
// public boolean removeAll(Collection<?> c)
//    Returns: true if this list changed as a result of the call
// public boolean retainAll(Collection<?> c)
//    Returns: true if this list changed as a result of the call

   static void test3() {
      System.out.println("\n --- test3: remove(Object), removeAll, retainAll  ----");
      Float[] A= {10f, 11f, 12f, 13f, 14f, 12f};  // auto box
      var S= List.of(new Float[]{9f, 11f, 13f, 15f}); 
      System.out.println("S: "+S);
      System.out.println("---");

      var AL0= new ArrayList<Float>(List.<Float>of(A));
      System.out.println("begin: "+AL0);
      AL0.remove(Float.valueOf(12f));
      System.out.println("after remove((Float)12f): "+AL0);
      System.out.println("---");

      var AL1= new ArrayList<Float>(List.of(A));
      System.out.println("begin: "+AL1);
      AL1.removeAll(S);
      System.out.println("after removeAll(S): "+AL1);
      System.out.println("---");

      var AL2= new ArrayList<Float>(List.of(A));
      System.out.println("begin: "+AL2);
      AL2.retainAll(S);
      System.out.println("after retainAll(S): "+AL2);
   }
/*
 --- test3: remove(Object), removeAll, retainAll  ----
S: [9.0, 11.0, 13.0, 15.0]
---
begin: [10.0, 11.0, 12.0, 13.0, 14.0, 12.0]
after remove((Float)12f): [10.0, 11.0, 13.0, 14.0, 12.0]
---
begin: [10.0, 11.0, 12.0, 13.0, 14.0, 12.0]
after removeAll(S): [10.0, 12.0, 14.0, 12.0]
---
begin: [10.0, 11.0, 12.0, 13.0, 14.0, 12.0]
after retainAll(S): [11.0, 13.0]
*/

   static void test3A_fail() {
      System.out.println("\n --- test3A_fail: remove(Object), removeAll, retainAll  ----");
      Wrap_f[] A= {
         new Wrap_f(10f), new Wrap_f(11f), new Wrap_f(12f),
         new Wrap_f(13f), new Wrap_f(14f), new Wrap_f(12f)
      }; 
      var S= List.of(new Wrap_f(9f), new Wrap_f(11f), 
                     new Wrap_f(13f), new Wrap_f(15f)); 
      System.out.println("S: "+S);
      System.out.println("---");

      var AL0= new ArrayList<Wrap_f>(List.<Wrap_f>of(A));
      System.out.println("begin: "+AL0);
      AL0.remove(new Wrap_f(12f));
      System.out.println("after remove(new Wrap_f(12f)): "+AL0);
      System.out.println("---");

      var AL1= new ArrayList<Wrap_f>(List.of(A));
      System.out.println("begin: "+AL1);
      AL1.removeAll(S);
      System.out.println("after removeAll(S): "+AL1);
      System.out.println("---");

      var AL2= new ArrayList<Wrap_f>(List.of(A));
      System.out.println("begin: "+AL2);
      AL2.retainAll(S);
      System.out.println("after retainAll(S): "+AL2);
   }
/*
 --- test3A_fail: remove(Object), removeAll, retainAll  ----
S: [9.0, 11.0, 13.0, 15.0]
---
begin: [10.0, 11.0, 12.0, 13.0, 14.0, 12.0]
after remove(new Wrap_f(12f)): [10.0, 11.0, 12.0, 13.0, 14.0, 12.0]
---
begin: [10.0, 11.0, 12.0, 13.0, 14.0, 12.0]
after removeAll(S): [10.0, 11.0, 12.0, 13.0, 14.0, 12.0]
---
begin: [10.0, 11.0, 12.0, 13.0, 14.0, 12.0]
after retainAll(S): []
*/

  static void test3B() {
      System.out.println("\n --- test3B: remove(Object), removeAll, retainAll  ----");
      WrapE_f[] A= {
         new WrapE_f(10f), new WrapE_f(11f), new WrapE_f(12f),
         new WrapE_f(13f), new WrapE_f(14f), new WrapE_f(12f)
      }; 
      var S= List.of(new WrapE_f(9f), new WrapE_f(11f), 
                     new WrapE_f(13f), new WrapE_f(15f)); 
      System.out.println("S: "+S);
      System.out.println("---");

      var AL0= new ArrayList<WrapE_f>(List.<WrapE_f>of(A));
      System.out.println("begin: "+AL0);
      AL0.remove(new WrapE_f(12f));
      System.out.println("after remove(new WrapE_f(12f)): "+AL0);
      System.out.println("---");

      var AL1= new ArrayList<WrapE_f>(List.of(A));
      System.out.println("begin: "+AL1);
      AL1.removeAll(S);
      System.out.println("after removeAll(S): "+AL1);
      System.out.println("---");

      var AL2= new ArrayList<WrapE_f>(List.of(A));
      System.out.println("begin: "+AL2);
      AL2.retainAll(S);
      System.out.println("after retainAll(S): "+AL2);
   }
/*
 --- test3B: remove(Object), removeAll, retainAll  ----
S: [9.0, 11.0, 13.0, 15.0]
---
begin: [10.0, 11.0, 12.0, 13.0, 14.0, 12.0]
after remove(new WrapE_f(12f)): [10.0, 11.0, 13.0, 14.0, 12.0]
---
begin: [10.0, 11.0, 12.0, 13.0, 14.0, 12.0]
after removeAll(S): [10.0, 12.0, 14.0, 12.0]
---
begin: [10.0, 11.0, 12.0, 13.0, 14.0, 12.0]
after retainAll(S): [11.0, 13.0]
*/







//-------------------------------------------------

   public static void main(String[] dummy){
      test1();

      test2();
      test2A();

      test3();
      test3A_fail();
      test3B();
   }

}
