import java.lang.Integer;   //: not necessary to import

//[ wrapped float
public class WrapE_f {
   public  //: encourage direct access 
   float v;  //: its value

   public WrapE_f(float value)  {  this.v= value;  }
   public WrapE_f()  {  this.v= 0.0f;  }

   @Override public String toString() {  
      return Float.toString(v);  
   }  

   @Override public boolean equals(Object o) { 
      if(o instanceof WrapE_f) {
         WrapE_f w= (WrapE_f)o; 
         return (this.v==w.v); 
      } 
      return false;  
   }  

/*
   @Override public WrapE_f clone() {  
      return new WrapE_f(this.v); 
   }
*/
}

 
class Test_WrapE_f {

   static void test_equals_Wrap_f() {
      System.out.println(" --- test_equals_Wrap_f ---"); 
      Wrap_f w1= new Wrap_f(15f);
      Wrap_f w2= new Wrap_f(15f);
      System.out.println(w1==w2); 
      System.out.println(w1.equals(w2)); 
      System.out.println();
   }
/*
 --- test_equals_Wrap_f ---
false
false
*/
   
   static void test_equals_WrapE_f() {
      System.out.println(" --- test_equals_WrapE_f ---"); 
      WrapE_f w1= new WrapE_f(15f);
      WrapE_f w2= new WrapE_f(15f);
      System.out.println(w1==w2); 
      System.out.println(w1.equals(w2)); 
      System.out.println();
   }
/*
 --- test_equals_WrapE_f ---
false
true
*/

   public static void main(String[] dummy) {
      test_equals_Wrap_f();
      test_equals_WrapE_f();
   } 

}