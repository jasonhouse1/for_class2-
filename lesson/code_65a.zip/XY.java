
public class XY {
   float x; 
   float y;  

   //static XY create() {    return new XY();   }
   XY() {   x=0f;  y=0f;   }   // default-ctor

   //static XY create(float x, float y) {

   XY(float x, float y) {
      this.x= x;   this.y=y;
   }

   //static XY create(XY src) { // copy

   XY(XY src) { // copy-ctor of XY
      this.x= src.x;   this.y=src.y;
   }

//   static void print(XY v) {
//   static void println(XY v) {

   @Override public String toString() {
      //return "("+Float.toString(this.x)+","+Float.toString(this.y)+")";
      return "("+this.x+","+this.y+")";
   }

/* not used in this chapter

   XY add(XY v2) {
      XY ans= new XY();
      ans.x= this.x+v2.x;
      ans.y= this.y+v2.y;
      return ans; 	
   }

   XY sub(XY v2) {
      return new XY(this.x-v2.x,  this.y-v2.y);
   }

   XY mul(float k) {
      return new XY(k*this.x, k*this.y);
   }

   float mul(XY v2) { //: inner product
      float ans;
      ans=this.x*v2.x+this.y*v2.y;
      return ans; 	
   }

   float wedge(XY v2) { //: wedge product
      float ans;
      ans= this.x*v2.y - this.y*v2.x;
      return ans; 	
   }

   float norm() {
      float ans= 0f;
//    ans= (float) Math.sqrt(this.x*this.x+this.y*this.y)
      ans= (float) Math.sqrt(this.mul(this));
      return ans; 	
   }

   float distance(XY v2) {
      float ans= 0f;
//    ans= this.sub(v2).norm();
      ans= this.sub(v2).norm();
      return ans; 	
   }

//------------------------------
//
// 沒有函數值的運算  addBy, .. 
//

   void setBy(XY v2) {
      this.x= v2.x;   this.y=v2.y;
   }

   void addBy(XY v2) {
      this.x += v2.x;  // i.e.  this.x=v1.x+v2.2
      this.y += v2.y;  //       this.y=v1.y+v2.y
   }

   void subBy(XY v2) {
      this.x -= v2.x;
      this.y -= v2.y;
   }

   void mulBy(float k) {
//    this.x=k*v1.x;  this.y=k*v1.y;
      this.x *= k ;  this.y *= k ;
   }

   public boolean equals(XY op2) {
      return this.x==op2.x && this.y==op2.y;
   }

   @Override public boolean equals(Object op2) {  // critical in ArrayList::contains(Object)
      if(op2==null) {
      //  throw new IllegalArgumentException("not support "+op2.getClass());  // bad design
          return false; 
      }
      else if(op2 instanceof XY) return this.equals((XY)op2); 
      else {
         // throw new IllegalArgumentException("not support "+op2.getClass()); 
              // bad design, only used before release.
         return false;
      }
   } 
*/

}

//=====================================

