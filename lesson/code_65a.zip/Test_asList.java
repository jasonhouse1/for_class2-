//import java.util.Arrays;
import java.util.List;
import java.util.ArrayList;

/*
compare
  public static <T> List<T> asList(T... a) in class java.util.Arrays
  static <E> List<E> of(E... elements) in interface List<E>
*/
/*
  var in Java 10(2018) like auto redefined in C++11(2011) 
*/

public class Test_asList {

   static void test1() {
      System.out.println("\n --- test1: actual types  ----");
//    auto L1= java.util.Arrays.asList("aaa", "bb", "cccc"); // ERR: it is in C++  
//    var L1= java.util.Arrays.asList("aaa", "bb", "cccc");  // OK in java
             // java 10: Local-Variable Type Inference
      List<String> L1= java.util.Arrays.asList("aaa", "bb", "cccc");
//    ArrayList<String> L1= Arrays.<String>asList("aaa", "bb", "cccc"); //: ERR
      System.out.println("L1: "+L1); 
      System.out.println("type of L1: "+L1.getClass()); //: class java.util.Arrays$ArrayList

      List<String> L2= List.of("aa", "b", "ccc"); // java9, immutable list
      System.out.println("L2: "+L2); 
      System.out.println("type of L2: "+L2.getClass()); //: class java.util.Arrays$ArrayList
   }
/*
 --- test1: actual types  ----
L1: [aaa, bb, cccc]
type of L1: class java.util.Arrays$ArrayList
L2: [aa, b, ccc]
type of L2: class java.util.ImmutableCollections$ListN
*/

   static void test2() {
      System.out.println("\n --- test2: null entry  ----");
      List<String> L1= java.util.Arrays.asList("", "bb", null, "dddd");  
      System.out.println("L1: "+L1); 
      List<String> L2;
      try{  
         L2= List.of("", "bb", null, "dddd"); // java9, immutable list
         System.out.println("L2: "+L2); 
      }
      catch (java.lang.NullPointerException xpt) {
         System.out.println("catch: "+xpt);
         L2= List.of("", "bb", "ccc", "dddd"); // java9, immutable list
         System.out.println("L2: "+L2); 
      } 
   }
/*
 --- test2: null entry  ----
L1: [, bb, null, dddd]
catch: java.lang.NullPointerException
L2: [, bb, ccc, dddd]
*/

   static void test3_1() {
      System.out.println("\n --- test3_1: modifiability on Arrays.asList ----");
      String[] A1= new String[]{"aaa", "bb", "cccc"};
      System.out.println("original A1: "+java.util.Arrays.toString(A1));
      List<String> L1= java.util.Arrays.asList(A1);
      ArrayList<String> AL1= new ArrayList<String>(L1);
      L1.set(0, "ZZZ");
      AL1.set(1, "KK");
      System.out.println("L1: "+L1); 
      System.out.println("A1: "+java.util.Arrays.toString(A1));  
            //!!! modify original arrsy
      System.out.println("AL1: "+AL1); 
      try{
         L1.add("d");
      }
      catch(java.lang.UnsupportedOperationException xpt) {
         System.out.println("on L1.add($), catch: "+xpt); 
      }
      AL1.add("ee");
      System.out.println("AL1: "+AL1);  
      System.out.println();  
   }
/*
 --- test3_1: modifiability on Arrays.asList ----
original A1: [aaa, bb, cccc]
L1: [ZZZ, bb, cccc]
A1: [ZZZ, bb, cccc]
AL1: [aaa, KK, cccc]
on L1.add($), catch: java.lang.UnsupportedOperationException
AL1: [aaa, KK, cccc, ee]
*/
   static void test3_2() {
      System.out.println("\n --- test3_2: modifiability on List.of  ----");
      String[] A2= new String[]{"aaa", "bb", "cccc"};
      System.out.println("original A2: "+java.util.Arrays.toString(A2));  
      List<String> L2= List.of(A2);  // java 9
      ArrayList<String> AL2= new ArrayList<String>(L2); 
 // java 9
      try {
         L2.set(0, "ZZZ");
      }
      catch(java.lang.UnsupportedOperationException xpt) {
         System.out.println("on L2.set(0,$), catch: "+xpt); 
         A2[0]= "ZZZ";
      }
      System.out.println("L2: "+L2); 
      System.out.println("A2: "+java.util.Arrays.toString(A2));  
      AL2.set(1, "KK");
      System.out.println("AL2: "+AL2); 
      try{
         L2.add("d");
      }
      catch(java.lang.UnsupportedOperationException xpt) {
         System.out.println("on L2.add($), catch: "+xpt); 
      }
      AL2.add("ee");
      System.out.println("AL2: "+AL2);  
   }

/*
 --- test3_2: modifiability on List.of  ----
original A2: [aaa, bb, cccc]
on L2.set(0,$), catch: java.lang.UnsupportedOperationException
L2: [aaa, bb, cccc]
A2: [ZZZ, bb, cccc]
AL2: [aaa, KK, cccc]
on L2.add($), catch: java.lang.UnsupportedOperationException
AL2: [aaa, KK, cccc, ee]
*/



   public static void main(String[] dummy) {
      test1();
      test2();
      test3_1();
      test3_2();
   }




}