import java.lang.Integer;   //: not necessary to import

//[ wrapped float
public class Wrap_f {
   public  //: encourage direct access 
   float v;  //: its value

   public Wrap_f(float value)  {  this.v= value;  }
   public Wrap_f()  {  this.v= 0.0f;  }

   @Override public String toString() {  
      return Float.toString(v);  
   }  
/*
   @Override public Wrap_f clone() {  
      return new Wrap_f(this.v); 
   }
*/
}

class Test_Wrap_f {
   public static void main(String[] dummy) {
      Wrap_f w1= new Wrap_f(15f);
   // Wrap_f w2= w1.clone(); //: only if Wrap_f supports public clone()
   } 


}