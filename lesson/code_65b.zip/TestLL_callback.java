import java.util.List;
import java.util.LinkedList;
import java.util.Iterator;
import java.util.function.UnaryOperator;
import java.util.function.Consumer;
import java.util.function.Predicate;

// access test
public class TestLL_callback {

//-------------------------------------------------

// public void forEach(Consumer<? super E> action)

// interface java.util.function.Consumer<T> {
//    void accept(T t) 
//    default Consumer<T> andThen(Consumer<? super T> after) 
// }

   static void pElm(Float x) {  System.out.print("("+x+") ");  }

   static class ClsPrintFloat<T> 
      implements java.util.function.Consumer<T> 
   {
      @Override public void accept(T x) {
         System.out.print("("+x+") ");
      }
   } 

   static void testRead() {
      System.out.println("\n --- testRead: forEach by passive iterator ----");
      Float[] A1= { 10f, 11f, 12f, 13f, 14f };  // auto box
      LinkedList<Float> LL1= 
         new LinkedList<Float>(java.util.List.<Float>of(A1));
      System.out.println("LL1: "+LL1);

      System.out.println(" use mtd ref: ");
      Consumer<Float> mtdRef= TestLL_callback::pElm;
      LL1.forEach(mtdRef);
      System.out.println();

      System.out.println(" use lambda: ");
      Consumer<Float> lambdaExp= 
         ( x->{ System.out.print("("+x+") "); } );
      LL1.forEach(lambdaExp);
      System.out.println();

      System.out.println(" use andThen: ");
      Consumer<Float> c1= 
         ( x->{ System.out.print("("); } );
      Consumer<Float> c2=
         c1.andThen(  
            x->{ System.out.print(x); } 
         );
      Consumer<Float> c3=
         c2.andThen(  
            x->{ System.out.print(") "); } 
         );
      LL1.forEach( c3 );
      System.out.println();

      System.out.println(" use nested class: ");
      Consumer<Float> nstCls= new ClsPrintFloat<Float>();
      LL1.forEach(nstCls);
      System.out.println();

   }
/*
 --- testRead: forEach by passive iterator ----
LL1: [10.0, 11.0, 12.0, 13.0, 14.0]
 use mtd ref:
(10.0) (11.0) (12.0) (13.0) (14.0)
 use lambda:
(10.0) (11.0) (12.0) (13.0) (14.0)
 use andThen:
(10.0) (11.0) (12.0) (13.0) (14.0)
 use nested class:
(10.0) (11.0) (12.0) (13.0) (14.0)

*/

   static void testRead_actI() {
      System.out.println("\n --- testRead_actI: forEach by active iterator ----");
      Float[] A1= { 10f, 11f, 12f, 13f, 14f };  // auto box
      LinkedList<Float> LL1= 
         new LinkedList<Float>(java.util.List.<Float>of(A1));
      System.out.println("LL1: "+LL1);

      System.out.println(" by iterator: ");
      java.util.Iterator<Float> itr= LL1.iterator(); 
      while( itr.hasNext() ) {
         Float x= itr.next();
         System.out.print("("+x+") ");   
      }  
      System.out.println();

      System.out.println(" by enhenced for: ");
      for(Float x: LL1) {
         System.out.print("("+x+") ");   
      }
      System.out.println();
   }
/*
 --- testRead_actI: forEach by active iterator ----
LL1: [10.0, 11.0, 12.0, 13.0, 14.0]
 by iterator:
(10.0) (11.0) (12.0) (13.0) (14.0)
 by enhenced for:
(10.0) (11.0) (12.0) (13.0) (14.0)
*/


//--------------------------------------------------

// public void replaceAll(UnaryOperator<E> operator)

// interface java.util.function.UnaryOperator<T> 
//    extends java.util.function.Function<T,T> {
//    T apply(T t);
// ]

   static Float mul10(Float x) {  return 10*x;  }

   static void testRW() {
      System.out.println("\n --- testRW: replaceAll by passive iterator  ----");
      Float[] A={ 10f, 11f, 12f, 13f };
      var L= java.util.List.<Float>of(A);
      var LL1= new LinkedList<Float>(L);
      System.out.println("LL1 begin: \n"+LL1);
      UnaryOperator<Float> mtd_ref= TestLL_callback::mul10;
      LL1.replaceAll(mtd_ref); 
      System.out.println("LL1 after replaceAll(mtd_ref): \n"
                         +LL1);
      System.out.println("original array: \n"
                         +java.util.Arrays.toString(A));

      System.out.println(" ---  ");
      var LL2= new LinkedList<Float>(L);
      System.out.println("LL2 begin: \n"+LL2);
      UnaryOperator<Float> lambdaExp= (x->10*x);
      LL2.replaceAll(lambdaExp);  
      System.out.println("LL2 after replaceAll(lambdaExp): \n"+LL2);
      System.out.println("original array: "+java.util.Arrays.toString(A));
   }
/*
 --- testRW: replaceAll by passive iterator  ----
LL1 begin:
[10.0, 11.0, 12.0, 13.0]
LL1 after replaceAll(mtd_ref):
[100.0, 110.0, 120.0, 130.0]
original array:
[10.0, 11.0, 12.0, 13.0]
 ---
LL2 begin:
[10.0, 11.0, 12.0, 13.0]
LL2 after replaceAll(lambdaExp):
[100.0, 110.0, 120.0, 130.0]
original array: [10.0, 11.0, 12.0, 13.0]
*/

   static void testRW_actI() {
      System.out.println("\n --- testRW_actI: replaceAll by active iterator ----");
      Float[] A={ 10f, 11f, 12f, 13f };
      var L= java.util.List.<Float>of(A);
      var LL1= new LinkedList<Float>(L);
      System.out.println("LL1 begin: \n"+LL1);
   // LL1.replaceAll(TestLL_callback::mul10);
      var itr= LL1.listIterator();  // will do 'set' 
      while(itr.hasNext()) {
         Float x= itr.next();
         itr.set(10*x); 
      }  
      System.out.println("LL1 after active replaceAll($): \n"
                         +LL1);
      System.out.println("original array: \n"
                         +java.util.Arrays.toString(A));
   }
/*
 --- testRW_actI: replaceAll by active iterator ----
LL1 begin: 
[10.0, 11.0, 12.0, 13.0]
LL1 after active replaceAll($):
[100.0, 110.0, 120.0, 130.0]
original array:
[10.0, 11.0, 12.0, 13.0]
*/


//-------------------------------------------------
// import java.util.function.Predicate;
/*
interface Predicate<T> {
   boolean test(T t);
   ...
}
public boolean removeIf(Predicate<? super E> filter)
Returns true if any elements were removed
*/

   static boolean isHigh(Float x) {
      return x>12f;
   }

   static void testRemoveIf() {
      System.out.println("\n --- testRemoveIf: removeIf by passive iterator ----");
      var L= List.<Float>of(10f, 11f, 12f, 13f, 14f, 15f);
      var LL1= new LinkedList<Float>(L);
      System.out.println("LL1 begin: \n"+LL1);
      Predicate<Float> mtdRef= TestLL_callback::isHigh; 
      LL1.removeIf(mtdRef);
      System.out.println("LL1 after removeIf(mtdRef): \n"+LL1);
      System.out.println("---");

      var LL2= new LinkedList<Float>(L);
      System.out.println("LL2 begin: \n"+LL2);
      Predicate<Float> lambdaExp= x->(x>12f) ;
      LL1.removeIf(lambdaExp);
      System.out.println("LL2 after removeIf(lambdaExp): \n"
                         +LL1);
      System.out.println();
   }
/*
 --- testRemoveIf: removeIf by passive iterator ----
LL1 begin:
[10.0, 11.0, 12.0, 13.0, 14.0, 15.0]
LL1 after removeIf(mtdRef):
[10.0, 11.0, 12.0]
---
LL2 begin:
[10.0, 11.0, 12.0, 13.0, 14.0, 15.0]
LL2 after removeIf(lambdaExp):
[10.0, 11.0, 12.0]
*/

   static void testRemoveIf_actI() {
      System.out.println("\n --- testRemoveIf_actI: removeIf by active iterator ----");
      var L= List.<Float>of(10f, 11f, 12f, 13f, 14f, 15f);
      var LL1= new LinkedList<Float>(L);
      System.out.println("LL1 begin: \n"+LL1);
      Iterator<Float> itr= LL1.iterator();
      while(itr.hasNext()) {
         Float x= itr.next();
      // if(TestLL_callback.isHigh(x)) {  
         if(x>12f) {  
            itr.remove();
         }  
      } 
      System.out.println("LL1 after removeIf(mtdRef): \n"+LL1);
      System.out.println();
   }
/*
 --- testRemoveIf_actI: removeIf by active iterator ----
LL1 begin:
[10.0, 11.0, 12.0, 13.0, 14.0, 15.0]
LL1 after removeIf(mtdRef):
[10.0, 11.0, 12.0]
*/

   public static void main(String[] dummy){
      testRW();        testRW_actI();
      testRead();      testRead_actI();
      testRemoveIf();  testRemoveIf_actI();
   }

}
