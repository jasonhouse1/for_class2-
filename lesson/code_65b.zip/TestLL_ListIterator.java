import java.util.List;
import java.util.LinkedList;
import java.util.Iterator;
import java.util.ListIterator;


class TestLL_ListIterator {

   static Float[] A1= {  5.0f, 5.1f, 5.2f, 5.3f, 5.4f };

 //------------------------------------------

   static void test_2way() {
      System.out.println("\n --- test_2way() --- ");
      LinkedList<Float> L1= new LinkedList<Float>( List.of(A1) );
      ListIterator<Float> i1= L1.listIterator(0);
   // ListIterator<Float> i1= L1.listIterator();
      while(i1.hasNext()) {
         Float elm= i1.next();
         System.out.print(" ("+elm+") "); 
      }
      System.out.println();

   // int s=L1.size();
      ListIterator<Float> i2= L1.listIterator(L1.size());
      while(i2.hasPrevious()) {
         Float elm= i2.previous();
         System.out.print(" ("+elm+") "); 
      }
      System.out.println();
   }
/*
 --- test_2way() ---
 (5.0)  (5.1)  (5.2)  (5.3)  (5.4)
 (5.4)  (5.3)  (5.2)  (5.1)  (5.0)
*/

   static void test_set() {
      System.out.println("\n --- test_set() --- ");
      LinkedList<Float> L1= new LinkedList<Float>( List.of(A1) );
      System.out.println("L1: "+L1);

      ListIterator<Float> i1= L1.listIterator();
      while(i1.hasNext()) {
         Float elm= i1.next();
         i1.set(elm+1);
      }
      System.out.println("L1: "+L1);

      while(i1.hasPrevious()) {
         Float elm= i1.previous();
         i1.set(elm+1);
      }
      System.out.println("L1: "+L1);
   }
/*
 --- test_set() ---
L1: [5.0, 5.1, 5.2, 5.3, 5.4]
L1: [6.0, 6.1, 6.2, 6.3, 6.4]
L1: [7.0, 7.1, 7.2, 7.3, 7.4]
*/

   static void test_add() {
      System.out.println("\n --- test_add() --- ");
      LinkedList<Float> L1= new LinkedList<Float>( List.of(A1) );
      System.out.println(L1);

      ListIterator<Float> i1= L1.listIterator();
      i1.next(); i1.add(90f);
      System.out.println("after i1.add(90f), L1: "+L1);
      System.out.println("i1.previous(): "+i1.previous()); 
      System.out.println("i1.next(): "+i1.next()); 
   }
/*
 --- test_add() ---
[5.0, 5.1, 5.2, 5.3, 5.4]
after i1.add(90f), L1: [5.0, 90.0, 5.1, 5.2, 5.3, 5.4]
i1.previous(): 90.0
i1.next(): 90.0
*/

   static void test_remove() {
      System.out.println("\n --- test_remove() --- ");
      LinkedList<Float> L1= new LinkedList<Float>( List.of(A1) );
      ListIterator<Float> i1= L1.listIterator();
      System.out.println(L1);
      System.out.println("next(): "+i1.next()); 
      System.out.println("next(): "+i1.next()); 
      i1.remove();  // return void 
      System.out.println(L1);
      System.out.println("next(): "+i1.next()); 
      i1.remove();  // return void 
      System.out.println(L1);
      System.out.println("previous(): "+i1.previous()); 
      i1.remove();  // return void 
      System.out.println(L1);
   }
/*
 --- test_remove() ---
[5.0, 5.1, 5.2, 5.3, 5.4]
next(): 5.0
next(): 5.1
[5.0, 5.2, 5.3, 5.4]
next(): 5.2
[5.0, 5.3, 5.4]
previous(): 5.0
[5.3, 5.4]
*/

   static void test_crash() {
      System.out.println("\n --- test_crash ---"); 
      var L= new LinkedList<Float>(List.of(7.1f, 7.2f, 7.3f));
      System.out.println("L: "+L); 

      ListIterator<Float> itr1, itr2;
      itr1= L.listIterator();
      System.out.println("itr1: "+itr1);

      L.add(99f);  // cause crash of itr  
      System.out.println("after L.add(99f), L: "+L); 

      itr1.hasNext();  // OK
      try{ 
         itr1.next(); 
      } catch(java.util.ConcurrentModificationException xpt) {
         System.out.println(
            "catch: ConcurrentModificationException on itr1.next()"
         );  
      }
      System.out.println("---"); 

      itr1= L.listIterator();
      System.out.println("itr1: "+itr1);
   // itr2= itr1.clone();              //Error: its an interface 
   // itr2= new Iterator<Float>(itr1); //Error: its an interface
      itr2= L.listIterator();

      System.out.println("itr2: "+itr2);
      System.out.println("itr1 across: "+itr1.next()); 
      System.out.println("itr2 across: "+itr2.next()); 
      itr2.remove(); 
      System.out.println("after itr2.remove(), L: "+L); 
      try{ 
         itr1.next();
      } catch(java.util.ConcurrentModificationException xpt) {
         System.out.println(
            "catch: ConcurrentModificationException on itr1.next()"
         );  
      }
      System.out.println("itr2 across: "+itr2.next()); 

      itr2.add(30f); 
      System.out.println("after itr2.add(30f), L: "+L); 
      try {
         itr2.set(70f);
      }
      catch(java.lang.IllegalStateException xpt) {
         System.out.println("catch IllegalStateException");
      }
      System.out.println("itr2 across: "+itr2.next()); 
      itr2.set(70f);
      System.out.println("after itr2.set(70f), L: "+L); 
   }
/*
 --- test_crash ---
L: [7.1, 7.2, 7.3]
itr1: java.util.LinkedList$ListItr@3e3abc88
after L.add(99f), L: [7.1, 7.2, 7.3, 99.0]
catch: ConcurrentModificationException on itr1.next()
---
itr1: java.util.LinkedList$ListItr@53d8d10a
itr2: java.util.LinkedList$ListItr@e9e54c2
itr1 across: 7.1
itr2 across: 7.1
after itr2.remove(), L: [7.2, 7.3, 99.0]
catch: ConcurrentModificationException on itr1.next()
itr2 across: 7.2
after itr2.add(30f), L: [7.2, 30.0, 7.3, 99.0]
catch IllegalStateException
itr2 across: 7.3
after itr2.set(70f), L: [7.2, 30.0, 70.0, 99.0]
*/

   public static void main(String[] dummy) {
      test_2way();
      test_set();
      test_add();
      test_remove();
      test_crash();
      System.out.println(" all OK " );
   }

}