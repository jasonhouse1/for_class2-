import java.util.List;
import java.util.ArrayList;
import java.util.function.Predicate;

// structure test
public class TestAL_Deque {

/*
   左端插入 public void addFirst(E e)
   右端插入 public void addLast(E e)
   左端移出 public E removeFirst() 空串列會拋出NoSuchElementException
   右端移出 public E removeLast()  串列會拋出NoSuchElementException
   左端查閱 public E getFirst() 空串列會拋出NoSuchElementException
   右端查閱 public E getFirst() 空串列會拋出NoSuchElementException
*/

// java 8 的ArrayList 沒有這些函數
// https://docs.oracle.com/javase/8/docs/api/java/util/ArrayList.html

// java 21 的ArrayList 有這些函數
// https://docs.oracle.com/en/java/javase/21/docs/api/java.base/java/util/ArrayList.html

   static void test1() {
      System.out.println("\n --- test1  ----");
      var L= List.<Float>of(10f, 11f, 12f);
      var LL1= new ArrayList<Float>(L);
      var LL2= new ArrayList<Float>(L);
      System.out.println("LL1: "+LL1);
      System.out.println("LL2: "+LL2);

      Float x;
      x= LL1.getFirst();
      System.out.println("LL1.getFirst(): "+x);
      x= LL2.get(0);
      System.out.println("LL2.get(0): "+x);
      x= LL1.getLast();
      System.out.println("LL1.getLast(): "+x);
      x= LL2.get(LL2.size()-1); 
      System.out.println("LL2.get(LL2.size()-1): "+x);

      x= 80f; 
      System.out.println("addFirst "+x);
      LL1.addFirst(x); System.out.println("LL1: "+LL1);
      LL2.add(0, x); System.out.println("LL2: "+LL2);
      x= 90f; 
      System.out.println("addLast "+x);
      LL1.addLast(x);  System.out.println("LL1: "+LL1);
      LL2.add(LL2.size(), x); System.out.println("LL2: "+LL2);

      x= LL1.removeFirst();
      System.out.print("remove "+x+"\t"); 
      System.out.println("LL1: "+LL1);
      x= LL2.remove(0); 
      System.out.print("remove "+x+"\t"); 
      System.out.println("LL2: "+LL2);
      x=LL1.removeLast(); 
      System.out.print("remove "+x+"\t"); 
      System.out.println("LL1: "+LL1);
      x=LL2.remove(LL2.size()-1); 
      System.out.print("remove "+x+"\t"); 
      System.out.println("LL2: "+LL2);
   }
/*
 --- test1  ----
LL1: [10.0, 11.0, 12.0]
LL2: [10.0, 11.0, 12.0]
LL1.getFirst(): 10.0
LL2.get(0): 10.0
LL1.getLast(): 12.0
LL2.get(LL2.size()-1): 12.0
addFirst 80.0
LL1: [80.0, 10.0, 11.0, 12.0]
LL2: [80.0, 10.0, 11.0, 12.0]
addLast 90.0
LL1: [80.0, 10.0, 11.0, 12.0, 90.0]
LL2: [80.0, 10.0, 11.0, 12.0, 90.0]
remove 80.0     LL1: [10.0, 11.0, 12.0, 90.0]
remove 80.0     LL2: [10.0, 11.0, 12.0, 90.0]
remove 90.0     LL1: [10.0, 11.0, 12.0]
remove 90.0     LL2: [10.0, 11.0, 12.0]
*/

   static void test2() {
      System.out.println("\n --- test2  ----");
      var LL1= new ArrayList<Float>();
      try {
         LL1.getFirst();
      } catch(java.util.NoSuchElementException xpt) {
         System.out.println("catch NoSuchElementException");
      }
      try {
         LL1.get(0);
      } catch(java.lang.IndexOutOfBoundsException xpt) {
         System.out.println("catch IndexOutOfBoundsException");
      }
      try {
         LL1.getLast();
      } catch(java.util.NoSuchElementException xpt) {
         System.out.println("catch NoSuchElementException");
      }
      try {
         LL1.get(LL1.size()-1);
      } catch(java.lang.IndexOutOfBoundsException xpt) {
         System.out.println("catch IndexOutOfBoundsException");
      }
      try {
         LL1.removeFirst();
      } catch(java.util.NoSuchElementException xpt) {
         System.out.println("catch NoSuchElementException");
      }
      try {
         LL1.remove(0);
      } catch(java.lang.IndexOutOfBoundsException xpt) {
         System.out.println("catch IndexOutOfBoundsException");
      }
      try {
         LL1.removeLast();
      } catch(java.util.NoSuchElementException xpt) {
         System.out.println("catch NoSuchElementException");
      }
      try {
         LL1.remove(LL1.size()-1);
      } catch(java.lang.IndexOutOfBoundsException xpt) {
         System.out.println("catch IndexOutOfBoundsException");
      }
   }
/*
 --- test2  ----
catch NoSuchElementException
catch IndexOutOfBoundsException
catch NoSuchElementException
catch IndexOutOfBoundsException
catch NoSuchElementException
catch IndexOutOfBoundsException
catch NoSuchElementException
catch IndexOutOfBoundsException
*/

//-------------------------------------------------
   public static void main(String[] dummy){
      test1();
      test2();
      System.out.println("\n all OK ");
   }

}
