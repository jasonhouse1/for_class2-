import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;


// Test clone()
public class TestLL_clone {


// in class java.util.LinkedList, 
//   public Object clone()
  static void test1() {
      System.out.println("\n --- test1: clone ----");
      String[] A0= { "aaa", "", "cc", "d", "ee" };
  //  LinkedList<String> LL1= 
      var LL1= 
         new LinkedList<String>(List.of(A0));
      System.out.println("LL1: "+LL1+" ( "+LL1.getClass()+" ) ");

      @SuppressWarnings("unchecked") 
  //  LinkedList<String> LL2= 
      var LL2= 
          (LinkedList<String>)LL1.clone(); 
      System.out.println("LL2: "+LL2+" ( "+LL2.getClass()+" ) ");

   // ArrayList<String> AL3= 
      var LL3= 
         new LinkedList<String>(LL1); 
      System.out.println("LL3: "+LL3+" ( "+LL3.getClass()+" ) ");
   }
/*
 --- test1: clone  ----
LL1: [aaa, , cc, d, ee] ( class java.util.LinkedList )
LL2: [aaa, , cc, d, ee] ( class java.util.LinkedList )
LL3: [aaa, , cc, d, ee] ( class java.util.LinkedList )
*/

  static void test2() {
      System.out.println("\n --- test2: shallow copy ----");
      LinkedList<Wrap_f> LL1= 
         new LinkedList<Wrap_f>(
            List.of(
                new Wrap_f(10.1f), new Wrap_f(10.2f), new Wrap_f(10.3f)
            )
         );
      System.out.println("LL1: "+LL1+" ( "+LL1.getClass()+" ) ");

      @SuppressWarnings("unchecked") 
      LinkedList<Wrap_f> LL2= (LinkedList<Wrap_f>)LL1.clone(); 
      System.out.println("LL2: "+LL2+" ( "+LL2.getClass()+" ) ");

      LL2.set(1, new Wrap_f(20));
      System.out.println("... after LL2.set(1, new Wrap_f(20)); "); 
      System.out.println("LL1: "+LL1+" ( "+LL1.getClass()+" ) ");
      System.out.println("LL2: "+LL2+" ( "+LL2.getClass()+" ) ");

      LL2.get(0).v+=3;
      LL2.get(1).v+=5;
      System.out.println("... after LL2.get(0).v+=3; LL2.get(1).v+=5; "); 
      System.out.println("LL1: "+LL1+" ( "+LL1.getClass()+" ) ");
      System.out.println("LL2: "+LL2+" ( "+LL2.getClass()+" ) ");
      System.out.println();
   }
/*
 --- test2: shallow copy ----
LL1: [10.1, 10.2, 10.3] ( class java.util.LinkedList )
LL2: [10.1, 10.2, 10.3] ( class java.util.LinkedList )
... after LL2.set(1, new Wrap_f(20));
LL1: [10.1, 10.2, 10.3] ( class java.util.LinkedList )
LL2: [10.1, 20.0, 10.3] ( class java.util.LinkedList )
... after LL2.get(0).v+=3; LL2.get(1).v+=5;
LL1: [13.1, 10.2, 10.3] ( class java.util.LinkedList )
LL2: [13.1, 25.0, 10.3] ( class java.util.LinkedList )
*/

  static void test3() {
      System.out.println("\n --- test3: deep copy ----");
      LinkedList<Wrap_f> LL1= 
         new LinkedList<Wrap_f>(
            List.of(
                new Wrap_f(10.1f), new Wrap_f(10.2f), new Wrap_f(10.3f)
            )
         );
      System.out.println("LL1: "+LL1+" ( "+LL1.getClass()+" ) ");

      LinkedList<Wrap_f> LL2= new LinkedList<Wrap_f>();
      for(int i=0; i<LL1.size(); i++) {
         LL2.add(new Wrap_f(LL1.get(i).v)); 
      // LL2.add(LL1.get(i).clone()); //: only if Wrap_f supports public clone()
      }
      System.out.println("LL2: "+LL2+" ( "+LL2.getClass()+" ) ");

      LL2.set(1, new Wrap_f(20));
      System.out.println("... after LL2.set(1, new Wrap_f(20)); "); 
      System.out.println("LL1: "+LL1+" ( "+LL1.getClass()+" ) ");
      System.out.println("LL2: "+LL2+" ( "+LL2.getClass()+" ) ");

      LL2.get(0).v+=3;
      LL2.get(1).v+=5;
      System.out.println("... after LL2.get(0).v+=3; LL2.get(1).v+=5; "); 
      System.out.println("LL1: "+LL1+" ( "+LL1.getClass()+" ) ");
      System.out.println("LL2: "+LL2+" ( "+LL2.getClass()+" ) ");
      System.out.println();
   }
/*
 --- test3: deep copy ----
LL1: [10.1, 10.2, 10.3] ( class java.util.LinkedList )
LL2: [10.1, 10.2, 10.3] ( class java.util.LinkedList )
... after LL2.set(1, new Wrap_f(20));
LL1: [10.1, 10.2, 10.3] ( class java.util.LinkedList )
LL2: [10.1, 20.0, 10.3] ( class java.util.LinkedList )
... after LL2.get(0).v+=3; LL2.get(1).v+=5;
LL1: [10.1, 10.2, 10.3] ( class java.util.LinkedList )
LL2: [13.1, 25.0, 10.3] ( class java.util.LinkedList )
*/

   public static void main(String[] dummy) {
      test1();
      test2();
      test3();
   }

}
