import java.util.List;
import java.util.LinkedList;
import java.util.function.Predicate;

// structure test
public class TestLL_restruct {

// public boolean add(E e)
// public void add(int idx, E elm)  must 0<=idx<=this.size()
// public boolean addAll(Collection<? extends E> c)
// public boolean addAll(int idx, Collection<? extends E> c)

   static void test1() {
      System.out.println("\n --- test1: add, addAll  ----");
      var L= List.of("aaa", "b", "cc");  // return type: List<String>
      var LL1= new LinkedList<String>(); // return type: LinkedList<String>
      LL1.addAll(L);
      System.out.println(LL1);
      try{
         LL1.add(4, "Z1");
      } catch(java.lang.IndexOutOfBoundsException xpt) {
         System.out.println("catch: "+xpt); 
      } 
      LL1.add("Z1");
      System.out.println(LL1);
      LL1.add(1, "Z2");
      System.out.println(LL1);
      LL1.addAll(2, List.of("Z3", "Z4", "Z5"));
      System.out.println(LL1);
   } 
/*
 --- test1: add, addAll  ----
[aaa, b, cc]
catch: java.lang.IndexOutOfBoundsException: Index: 4, Size: 3
[aaa, b, cc, Z1]
[aaa, Z2, b, cc, Z1]
[aaa, Z2, Z3, Z4, Z5, b, cc, Z1]
*/

//-------------------------------------------------
// public void clear()
// public E remove(int index), 
//     return the element removed from the list
// public boolean remove(Object o)
//     Return true if this list contained the specified element

   static void test2() {
      System.out.println("\n --- test2  ----");
      var L= List.<Float>of(10f, 11f, 12f, 13f, 14f);
      var LL1= new LinkedList<Float>(L);
      System.out.println("begin: "+LL1);
      Float elm= LL1.remove(0);
      System.out.println("after remove(0): "+LL1);
      System.out.println("removed element: "+elm);
   try{ 
      Float elm1= LL1.remove(5);
   }
   catch(IndexOutOfBoundsException xpt) {
      System.out.println("catch: "+xpt); 
   }
      LL1.clear();
      System.out.println("after clear(): "+LL1);
      System.out.println("isEmpty: "+LL1.isEmpty());
   }
/*
 --- test2  ----
begin: [10.0, 11.0, 12.0, 13.0, 14.0]
after remove(0): [11.0, 12.0, 13.0, 14.0]
removed element: 10.0
catch: java.lang.IndexOutOfBoundsException: Index: 5, Size: 4
after clear(): []
isEmpty: true
*/

//-------------------------------------------------
// protected void removeRange(int fromIdx, int toIdx)
// public List<E> subList(int fromIdx, int toIdx) 
//     Returns a view of the portion of this list 

   static void test2A() {
      System.out.println("\n --- test2A  ----");
      var L= List.<Float>of(10f, 11f, 12f, 13f, 14f);
      var LL1= new LinkedList<Float>(L);
      System.out.println("begin: "+LL1);
//    LL1.removeRange(1,3); // ERR: protected access
      List<Float> r= LL1.subList(1,3); // a view of LL1
      System.out.println("r, LL1.subList(1,3): "+r
                             +"("+r.getClass()+")");
      r.clear();
      System.out.println("after r.clear(): "+LL1);
   }
/*
 --- test2A  ----
begin: [10.0, 11.0, 12.0, 13.0, 14.0]
r, LL1.subList(1,3): [11.0, 12.0](class java.util.AbstractList$SubList)
after r.clear(): [10.0, 13.0, 14.0]
*/


//-------------------------------------------------
// public boolean removeAll(Collection<?> c)
//    Returns: true if this list changed as a result of the call
// public boolean retainAll(Collection<?> c)
//    Returns: true if this list changed as a result of the call
   static void test3() {
      System.out.println("\n --- test3: remove(Object), removeAll, retainAll  ----");
      Float[] A= {10f, 11f, 12f, 13f, 14f, 12f};  // auto box
      var S= List.of(new Float[]{9f, 11f, 13f, 15f}); 
      System.out.println("S: "+S);
      System.out.println("---");

      var LL0= new LinkedList<Float>(List.<Float>of(A));
      System.out.println("begin: "+LL0);
      LL0.remove(Float.valueOf(12f));
      System.out.println("after remove((Float)12f): "+LL0);
      System.out.println("---");

      var LL1= new LinkedList<Float>(List.of(A));
      System.out.println("begin: "+LL1);
      LL1.removeAll(S);
      System.out.println("after removeAll(S): "+LL1);
      System.out.println("---");

      var LL2= new LinkedList<Float>(List.of(A));
      System.out.println("begin: "+LL2);
      LL2.retainAll(S);
      System.out.println("after retainAll(S): "+LL2);
   }
/*
 --- test3: remove(Object), removeAll, retainAll  ----
S: [9.0, 11.0, 13.0, 15.0]
---
begin: [10.0, 11.0, 12.0, 13.0, 14.0, 12.0]
after remove((Float)12f): [10.0, 11.0, 13.0, 14.0, 12.0]
---
begin: [10.0, 11.0, 12.0, 13.0, 14.0, 12.0]
after removeAll(S): [10.0, 12.0, 14.0, 12.0]
---
begin: [10.0, 11.0, 12.0, 13.0, 14.0, 12.0]
after retainAll(S): [11.0, 13.0]
*/

   static void test3A_fail() {
      System.out.println("\n --- test3A_fail: remove(Object), removeAll, retainAll  ----");
      Wrap_f[] A= {
         new Wrap_f(10f), new Wrap_f(11f), new Wrap_f(12f),
         new Wrap_f(13f), new Wrap_f(14f), new Wrap_f(12f)
      }; 
      var S= List.of(new Wrap_f(9f), new Wrap_f(11f), 
                     new Wrap_f(13f), new Wrap_f(15f)); 
      System.out.println("S: "+S);
      System.out.println("---");

      var LL0= new LinkedList<Wrap_f>(List.<Wrap_f>of(A));
      System.out.println("begin: "+LL0);
      LL0.remove(new Wrap_f(12f));
      System.out.println("after remove(new Wrap_f(12f)): "+LL0);
      System.out.println("---");

      var LL1= new LinkedList<Wrap_f>(List.of(A));
      System.out.println("begin: "+LL1);
      LL1.removeAll(S);
      System.out.println("after removeAll(S): "+LL1);
      System.out.println("---");

      var LL2= new LinkedList<Wrap_f>(List.of(A));
      System.out.println("begin: "+LL2);
      LL2.retainAll(S);
      System.out.println("after retainAll(S): "+LL2);
   }
/*
 --- test3A_fail: remove(Object), removeAll, retainAll  ----
S: [9.0, 11.0, 13.0, 15.0]
---
begin: [10.0, 11.0, 12.0, 13.0, 14.0, 12.0]
after remove(new Wrap_f(12f)): [10.0, 11.0, 12.0, 13.0, 14.0, 12.0]
---
begin: [10.0, 11.0, 12.0, 13.0, 14.0, 12.0]
after removeAll(S): [10.0, 11.0, 12.0, 13.0, 14.0, 12.0]
---
begin: [10.0, 11.0, 12.0, 13.0, 14.0, 12.0]
after retainAll(S): []
*/

  static void test3B() {
      System.out.println("\n --- test3B: remove(Object), removeAll, retainAll  ----");
      WrapE_f[] A= {
         new WrapE_f(10f), new WrapE_f(11f), new WrapE_f(12f),
         new WrapE_f(13f), new WrapE_f(14f), new WrapE_f(12f)
      }; 
      var S= List.of(new WrapE_f(9f), new WrapE_f(11f), 
                     new WrapE_f(13f), new WrapE_f(15f)); 
      System.out.println("S: "+S);
      System.out.println("---");

      var LL0= new LinkedList<WrapE_f>(List.<WrapE_f>of(A));
      System.out.println("begin: "+LL0);
      LL0.remove(new WrapE_f(12f));
      System.out.println("after remove(new WrapE_f(12f)): "+LL0);
      System.out.println("---");

      var LL1= new LinkedList<WrapE_f>(List.of(A));
      System.out.println("begin: "+LL1);
      LL1.removeAll(S);
      System.out.println("after removeAll(S): "+LL1);
      System.out.println("---");

      var LL2= new LinkedList<WrapE_f>(List.of(A));
      System.out.println("begin: "+LL2);
      LL2.retainAll(S);
      System.out.println("after retainAll(S): "+LL2);
   }
/*
 --- test3B: remove(Object), removeAll, retainAll  ----
S: [9.0, 11.0, 13.0, 15.0]
---
begin: [10.0, 11.0, 12.0, 13.0, 14.0, 12.0]
after remove(new WrapE_f(12f)): [10.0, 11.0, 13.0, 14.0, 12.0]
---
begin: [10.0, 11.0, 12.0, 13.0, 14.0, 12.0]
after removeAll(S): [10.0, 12.0, 14.0, 12.0]
---
begin: [10.0, 11.0, 12.0, 13.0, 14.0, 12.0]
after retainAll(S): [11.0, 13.0]
*/

//-------------------------------------------------
   public static void main(String[] dummy){
      test1();

      test2();
      test2A();

      test3();
      test3A_fail();
      test3B();
   }

}
