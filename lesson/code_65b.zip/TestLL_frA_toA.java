import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;


// Test Array FromTo
public class TestLL_frA_toA {

  static void test1() {
      System.out.println("\n --- test1: Array to LinkedList  ----");
      Wrap_f[] A0= { 
         new Wrap_f(10.1f), new Wrap_f(10.2f), new Wrap_f(10.3f)
      };
      System.out.println("A0: "+Arrays.toString(A0)
                         +" ( "+A0.getClass()+" ) ");
  //  LinkedList<Wrap_f> LL1= 
      var LL1= 
         new LinkedList<Wrap_f>(List.of(A0));
      System.out.println("LL1: "+LL1+" ( "+LL1.getClass()+" ) ");
   } 
/*
 --- test1: Array to LinkedList  ----
A0: [10.1, 10.2, 10.3] ( class [LWrap_f; )
LL1: [10.1, 10.2, 10.3] ( class java.util.LinkedList )
*/


  static void test2() {
      System.out.println("\n --- test2: LinkedList to Array  ----");
      Wrap_f[] A0= { 
         new Wrap_f(10.1f), new Wrap_f(10.2f), new Wrap_f(10.3f)
      };
      System.out.println("A0: "+Arrays.toString(A0)
                          +" ( "+A0.getClass()+" ) ");
   // LinkedList<Wrap_f> LL1= 
      var LL1=  
         new LinkedList<Wrap_f>();
      for(int i=0; i<A0.length; i++) {
         LL1.add(A0[i]);
      }  
      System.out.println("LL1: "+LL1+" ( "+ LL1.getClass()+" ) ");

      Wrap_f[] A1= new Wrap_f[LL1.size()];
      LL1.<Wrap_f>toArray(A1); 
   // LL1.toArray(A1); 
      System.out.println("A1: "+Arrays.toString(A1)
                           +" ( "+A1.getClass()+" ) ");
  }
/*
 --- test2: LinkedList to Array  ----
A0: [10.1, 10.2, 10.3] ( class [LWrap_f; )
LL1: [10.1, 10.2, 10.3] ( class java.util.LinkedList )
A1: [10.1, 10.2, 10.3] ( class [LWrap_f; )
*/

  static void test2_bad() {
      System.out.println("\n --- test2_bad: LinkedList to Array  ----");
      Wrap_f[] A0= { 
         new Wrap_f(10.1f), new Wrap_f(10.2f), new Wrap_f(10.3f)
      };
      System.out.println("A0: "+Arrays.toString(A0)
                         +" ( "+A0.getClass()+" ) ");
   // LinkedList<Wrap_f> LL1= new LinkedList<Wrap_f>();
      var LL1= new LinkedList<Wrap_f>();
      for(int i=0; i<A0.length; i++) {
         LL1.add(A0[i]);
      }  
      System.out.println("LL1: "+LL1+" ( "+ LL1.getClass() +" ) ");

      Object[] A5= LL1.toArray();
      System.out.println("A5: "+Arrays.toString(A5)
                         +" ( "+A5.getClass()+" ) ");
      Wrap_f[] A6;
      try{
         A6= (Wrap_f[])A5;
      }
      catch(java.lang.ClassCastException xpt) {
         System.out.println("catch: "+xpt); 
      }  
/*  
    in java.util.Arrays
    public static 
    <T,U> T[] copyOf(U[] original, int newLen,
                     Class<? extends T[]> newType)
*/
      A6= 
      // Arrays.<String,Object>copyOf(A5, A5.length, String[].class);
         Arrays.copyOf(A5, A5.length, Wrap_f[].class);
      System.out.println("A6: "+Arrays.toString(A6)
                         +" ( "+A6.getClass()+" ) ");
   } 
/*
 --- test2_bad: LinkedList to Array  ----
A0: [10.1, 10.2, 10.3] ( class [LWrap_f; )
LL1: [10.1, 10.2, 10.3] ( class java.util.LinkedList )
A5: [10.1, 10.2, 10.3] ( class [Ljava.lang.Object; )
catch: java.lang.ClassCastException: class [Ljava.lang.Object; cannot be cast to class [LWrap_f; ([Ljava.lang.Object; is in module java.base of loader 'bootstrap'; [LWrap_f; is in unnamed module of loader 'app')
A6: [10.1, 10.2, 10.3] ( class [LWrap_f; )
*/



   public static void main(String[] dummy) {
      test1();
      test2();
      test2_bad();
   }

}
