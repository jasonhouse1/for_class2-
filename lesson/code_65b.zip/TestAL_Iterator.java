import java.util.Arrays;
import java.util.List;
import java.util.ArrayList;
import java.util.ArrayList;
import java.util.Iterator;

/*
List<E> extends Collection<E>, Iterable<E>

java.lang.Object
 + java.util.AbstractCollection<E> implements Collection<E>, Iterable<E>
     + java.util.AbstractList<E>   implements List<E>
         + java.util.ArrayList<E>  implements Serializable, Cloneable, RandomAccess

Interface java.util.Iterator<E> {
   boolean hasNext()
   E next()
   default void remove()
   default void forEachRemaining(Consumer<? super E> action)
}

*/

public class TestAL_Iterator {

 //--------------------------------
   static void test_next_1() {
      System.out.println("\n --- test_next_1: modify ptr ---"); 
      var fA1= new Float[] { 5.0f, 5.1f, 5.2f, 5.3f, 5.4f  };
      System.out.println("fA1: "+Arrays.toString(fA1)); 

      var AL1= new ArrayList<Float>(List.of(fA1));
      System.out.println("AL1: "+AL1); 
      
      for(Iterator<Float> itr= AL1.iterator(); itr.hasNext();    ) {
         Float x= itr.next();
         System.out.print(x+"\t"); 
      }  
      System.out.println(); 
      for(Iterator<Float> itr= AL1.iterator(); itr.hasNext();   ) {
         Float x= itr.next();
         // x*=10;   // auto box-unbox
         // x=x*10;  // auto box-unbox
         x= Float.valueOf(x.floatValue()*10); // manually box-unbox
             // just modify the copy 
         System.out.print(x+"\t"); 
      }  
      System.out.println(); 
      System.out.println("AL1: "+AL1); 
      System.out.println("fA1: "+Arrays.toString(fA1)); 
   }
/*
 --- test_next_1: modify ptr ---
fA1: [5.0, 5.1, 5.2, 5.3, 5.4]
AL1: [5.0, 5.1, 5.2, 5.3, 5.4]
5.0     5.1     5.2     5.3     5.4
50.0    51.0    52.0    53.0    54.0
AL1: [5.0, 5.1, 5.2, 5.3, 5.4]
fA1: [5.0, 5.1, 5.2, 5.3, 5.4]
*/

   static void test_next_2() {
      System.out.println("\n --- test_next_2: modify obj ---"); 

      var WfA2= new Wrap_f[] { 
         new Wrap_f(6.0f), new Wrap_f(6.1f), new Wrap_f(6.2f), 
         new Wrap_f(6.3f), new Wrap_f(6.4f), 
      };
      System.out.println("WfA2: "+Arrays.toString(WfA2)); 

      var AL2= new ArrayList<Wrap_f>(List.of(WfA2));
      System.out.println("AL2: "+AL2); 

      for(Iterator<Wrap_f> itr= AL2.iterator(); itr.hasNext();    ) {
         Wrap_f x= itr.next();
         System.out.print(x+"\t"); 
      }  
      System.out.println(); 
      for(Iterator<Wrap_f> itr= AL2.iterator(); itr.hasNext();   ) {
         Wrap_f x= itr.next();
         x.v*=10;    // modify the shared object
         System.out.print(x+"\t"); 
      }  
      System.out.println(); 

      System.out.println("AL2: "+AL2); 

      System.out.println("WfA2: "+Arrays.toString(WfA2)); 
      System.out.println(); 
   }
/*
 --- test_next_2: modify obj ---
WfA2: [6.0, 6.1, 6.2, 6.3, 6.4]
AL2: [6.0, 6.1, 6.2, 6.3, 6.4]
6.0     6.1     6.2     6.3     6.4
60.0    61.0    62.0    63.0    64.0
AL2: [60.0, 61.0, 62.0, 63.0, 64.0]
WfA2: [60.0, 61.0, 62.0, 63.0, 64.0]
*/

   static void test_forEachRemaining() {
      System.out.println("\n --- test_forEachRemaining ---"); 
      var AL1= new ArrayList<Float>(
                  List.<Float>of(5.0f, 5.1f, 5.2f, 5.3f, 5.4f)
               );
      System.out.println("AL1: "+AL1); 

      AL1.forEach( 
         TestLL_callback::pElm
      );
      System.out.println(); 

      Iterator<Float> itr;
      itr= AL1.iterator();
      while(itr.hasNext()) { 
         Float x=itr.next();   System.out.print("<"+x+"> ");
         if(x>=5.1f) break;
      }
      itr.forEachRemaining(
         TestLL_callback::pElm
      );  
      System.out.println(); 

      itr= AL1.iterator();
      while(itr.hasNext()) { 
         Float x=itr.next();   System.out.print("<"+x+"> ");
         if(x>=5.1f) break;
      }
    //[ simulate forEachRemaining
      while(itr.hasNext()) {
         TestLL_callback.pElm(itr.next()); 
      }
      System.out.println(); 
   }
/*
 --- test_forEachRemaining ---
AL1: [5.0, 5.1, 5.2, 5.3, 5.4]
(5.0) (5.1) (5.2) (5.3) (5.4)
<5.0> <5.1> (5.2) (5.3) (5.4)
<5.0> <5.1> (5.2) (5.3) (5.4)
*/

   static void test_remove() {
      System.out.println("\n --- test_remove ---"); 
      var fA1= new Float[] { 5.0f, 5.1f, 5.2f, 5.3f, 5.4f  };
      System.out.println("fA1: "+Arrays.toString(fA1)); 
      var AL1= new ArrayList<Float>(List.of(fA1));
      System.out.println("AL1: "+AL1); 

      Iterator<Float> itr= AL1.iterator();
   try{ 
      itr.remove();  // IllegalStateException
   } catch(IllegalStateException xpt) {
      System.out.println("catch: IllegalStateException");
   }
      Float x= itr.next();
      System.out.println("across: "+x);
      itr.remove();
      System.out.println("after remove(), AL1: "+AL1); 
   try{ 
      itr.remove();
   } catch(IllegalStateException xpt) {
      System.out.println("catch: IllegalStateException for double remove()");
   }
      System.out.println("across: "+itr.next());
      System.out.println("across: "+itr.next());
      itr.remove();
      System.out.println("after remove(), AL1: "+AL1); 
      System.out.println("across: "+itr.next());

      System.out.println("fA1: "+Arrays.toString(fA1)); 

   }
/*
 --- test_remove ---
fA1: [5.0, 5.1, 5.2, 5.3, 5.4]
AL1: [5.0, 5.1, 5.2, 5.3, 5.4]
catch: IllegalStateException
across: 5.0
after remove(), AL1: [5.1, 5.2, 5.3, 5.4]
catch: IllegalStateException for double remove()
across: 5.1
across: 5.2
after remove(), AL1: [5.1, 5.3, 5.4]
across: 5.3
fA1: [5.0, 5.1, 5.2, 5.3, 5.4]
*/


   static void test_crash() {
      System.out.println("\n --- test_crash ---"); 
      var L= new ArrayList<Float>(List.of(7.1f, 7.2f, 7.3f));
      System.out.println("L: "+L); 

      Iterator<Float> itr1, itr2;
      itr1= L.iterator();
      System.out.println("itr1: "+itr1);

      L.add(99f);  // cause crash of itr  
      System.out.println("after L.add(99f), L: "+L); 

      itr1.hasNext();  // OK
      try{ 
         itr1.next(); 
      } catch(java.util.ConcurrentModificationException xpt) {
         System.out.println(
            "catch: ConcurrentModificationException on itr1.next()"
         );  
      }
      System.out.println("---"); 

      itr1= L.iterator();
      System.out.println("itr1: "+itr1);
      itr2= L.iterator();
      System.out.println("itr2: "+itr2);
      System.out.println("itr1 across: "+itr1.next()); 
      System.out.println("itr2 across: "+itr2.next()); 
      itr2.remove(); 
      System.out.println("after itr2.remove(), L: "+L); 
      try{ 
         itr1.next();
      } catch(java.util.ConcurrentModificationException xpt) {
         System.out.println(
            "catch: ConcurrentModificationException on itr1.next()"
         );  
      }
      System.out.println("itr2 across: "+itr2.next()); 

// detecting JDK's implementation
     try{ 
      var litr2= (java.util.ListIterator<Float>)itr2;
      System.out.println("litr2: "+litr2);
      System.out.println("litr2 back-across: "+litr2.previous()); 
     } catch(java.lang.ClassCastException xpt) {
        System.out.println("catch ClassCastException");
     }

   }
/*
 --- test_crash ---
L: [7.1, 7.2, 7.3]
itr1: java.util.ArrayList$Itr@7229724f
after L.add(99f), L: [7.1, 7.2, 7.3, 99.0]
catch: ConcurrentModificationException on itr1.next()
---
itr1: java.util.ArrayList$Itr@119d7047
itr2: java.util.ArrayList$Itr@776ec8df
itr1 across: 7.1
itr2 across: 7.1
after itr2.remove(), L: [7.2, 7.3, 99.0]
catch: ConcurrentModificationException on itr1.next()
itr2 across: 7.2
catch ClassCastException
*/

   public static void main(String[] dummy) {
      test_next_1();
      test_next_2();
      test_forEachRemaining();
      test_remove();
      test_crash();
      System.out.println(" all OK "  );
   }

}

//====================================================
