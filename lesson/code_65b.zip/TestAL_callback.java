import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.function.UnaryOperator;
import java.util.function.Consumer;
import java.util.function.Predicate;

// access test
public class TestAL_callback {

//-------------------------------------------------

// public void forEach(Consumer<? super E> action)

// interface java.util.function.Consumer<T> {
//    void accept(T t) 
//    default Consumer<T> andThen(Consumer<? super T> after) 
// }

   static void pElm(Float x) {  System.out.print("("+x+") ");  }

   static class ClsPrintFloat<T> 
      implements java.util.function.Consumer<T> 
   {
      @Override public void accept(T x) {
         System.out.print("("+x+") ");
      }
   } 

   static void testRead() {
      System.out.println("\n --- testRead: forEach by passive iterator ----");
      Float[] A1= { 10f, 11f, 12f, 13f, 14f };  // auto box
      ArrayList<Float> AL1= 
         new ArrayList<Float>(java.util.List.<Float>of(A1));
      System.out.println("AL1: "+AL1);

      System.out.println(" use mtd ref: ");
      Consumer<Float> mtdRef= TestAL_callback::pElm;
      AL1.forEach(mtdRef);
      System.out.println();

      System.out.println(" use lambda: ");
      Consumer<Float> lambdaExp= 
         ( x->{ System.out.print("("+x+") "); } );
      AL1.forEach(lambdaExp);
      System.out.println();

      System.out.println(" use andThen: ");
      Consumer<Float> c1= 
         ( x->{ System.out.print("("); } );
      Consumer<Float> c2=
         c1.andThen(  
            x->{ System.out.print(x); } 
         );
      Consumer<Float> c3=
         c2.andThen(  
            x->{ System.out.print(") "); } 
         );
      AL1.forEach( c3 );
      System.out.println();

      System.out.println(" use nested class: ");
      Consumer<Float> nstCls= new ClsPrintFloat<Float>();
      AL1.forEach(nstCls);
      System.out.println();

   }
/*
 --- testRead: forEach by passive iterator ----
AL1: [10.0, 11.0, 12.0, 13.0, 14.0]
 use mtd ref:
(10.0) (11.0) (12.0) (13.0) (14.0)
 use lambda:
(10.0) (11.0) (12.0) (13.0) (14.0)
 use andThen:
(10.0) (11.0) (12.0) (13.0) (14.0)
 use nested class:
(10.0) (11.0) (12.0) (13.0) (14.0)

*/

   static void testRead_actI() {
      System.out.println("\n --- testRead_actI: forEach by active iterator ----");
      Float[] A1= { 10f, 11f, 12f, 13f, 14f };  // auto box
      ArrayList<Float> AL1= 
         new ArrayList<Float>(java.util.List.<Float>of(A1));
      System.out.println("AL1: "+AL1);

      System.out.println(" by iterator: ");
      java.util.Iterator<Float> itr= AL1.iterator(); 
      while( itr.hasNext() ) {
         Float x= itr.next();
         System.out.print("("+x+") ");   
      }  
      System.out.println();

      System.out.println(" by enhenced for: ");
      for(Float x: AL1) {
         System.out.print("("+x+") ");   
      }
      System.out.println();
   }
/*
 --- testRead_actI: forEach by active iterator ----
AL1: [10.0, 11.0, 12.0, 13.0, 14.0]
 by iterator:
(10.0) (11.0) (12.0) (13.0) (14.0)
 by enhenced for:
(10.0) (11.0) (12.0) (13.0) (14.0)
*/

   static void testRead_idxI() {
      System.out.println("\n --- testRead_idxI: forEach by index ----");
      Float[] A1= { 10f, 11f, 12f, 13f, 14f };  // auto box
      ArrayList<Float> AL1= 
         new ArrayList<Float>(java.util.List.<Float>of(A1));
      System.out.println("AL1: "+AL1);

      System.out.println(" by iterator: ");
      for(int i=0; i<AL1.size(); i++) {
         Float x= AL1.get(i);
         System.out.print("("+x+") ");   
      }  
      System.out.println();
   }
/*
 --- testRead_idxI: forEach by index ----
AL1: [10.0, 11.0, 12.0, 13.0, 14.0]
 by iterator:
(10.0) (11.0) (12.0) (13.0) (14.0)
*/


//-------------------------------------------------



// public void replaceAll(UnaryOperator<E> operator)

// interface java.util.function.UnaryOperator<T> 
//    extends java.util.function.Function<T,T> {
//    T apply(T t);
// ]

   static Float mul10(Float x) {  return 10*x;  }

   static void testRW() {
      System.out.println("\n --- testRW: replaceAll by passive iterator  ----");
      Float[] A={ 10f, 11f, 12f, 13f };
      var L= java.util.List.<Float>of(A);
      var AL1= new ArrayList<Float>(L);
      System.out.println("AL1 begin: \n"+AL1);
      UnaryOperator<Float> mtd_ref= TestAL_callback::mul10;
      AL1.replaceAll(mtd_ref); 
      System.out.println("AL1 after replaceAll(mtd_ref): \n"
                         +AL1);
      System.out.println("original array: \n"
                         +java.util.Arrays.toString(A));

      System.out.println(" ---  ");
      var AL2= new ArrayList<Float>(L);
      System.out.println("AL2 begin: \n"+AL2);
      UnaryOperator<Float> lambdaExp= (x->10*x);
      AL2.replaceAll(lambdaExp);  
      System.out.println("AL2 after replaceAll(lambdaExp): \n"+AL2);
      System.out.println("original array: "+java.util.Arrays.toString(A));
   }
/*
 --- testRW: replaceAll by passive iterator  ----
AL1 begin:
[10.0, 11.0, 12.0, 13.0]
AL1 after replaceAll(mtd_ref):
[100.0, 110.0, 120.0, 130.0]
original array:
[10.0, 11.0, 12.0, 13.0]
 ---
AL2 begin:
[10.0, 11.0, 12.0, 13.0]
AL2 after replaceAll(lambdaExp):
[100.0, 110.0, 120.0, 130.0]
original array: [10.0, 11.0, 12.0, 13.0]
*/

   static void testRW_actI() {
      System.out.println("\n --- testRW_actI: replaceAll by active iterator ----");
      Float[] A={ 10f, 11f, 12f, 13f };
      var L= java.util.List.<Float>of(A);
      var AL1= new ArrayList<Float>(L);
      System.out.println("AL1 begin: \n"+AL1);
   // AL1.replaceAll(TestAL_callback::mul10);
      var itr= AL1.listIterator();  // will do 'set' 
      while(itr.hasNext()) {
         Float x= itr.next();
         itr.set(10*x); 
      }  
      System.out.println("AL1 after active replaceAll($): \n"
                         +AL1);
      System.out.println("original array: \n"
                         +java.util.Arrays.toString(A));
   }
/*
 --- testRW_actI: replaceAll by active iterator ----
AL1 begin: 
[10.0, 11.0, 12.0, 13.0]
AL1 after active replaceAll($):
[100.0, 110.0, 120.0, 130.0]
original array:
[10.0, 11.0, 12.0, 13.0]
*/

   static void testRW_idx() {
      System.out.println("\n --- testRW_idx: replaceAll by index ----");
      Float[] A={ 10f, 11f, 12f, 13f };
      var L= java.util.List.<Float>of(A);
      var AL1= new ArrayList<Float>(L);
      System.out.println("AL1 begin: \n"+AL1);
   // AL1.replaceAll(TestAL_callback::mul10);
      for(int i=0; i<AL1.size(); i++) {
         Float x= AL1.get(i);
         AL1.set(i, 10*x); 
      }  
      System.out.println("AL1 after index replaceAll($): \n"
                         +AL1);
      System.out.println("original array: \n"
                         +java.util.Arrays.toString(A));
   }
/*
 --- testRW_idx: replaceAll by index ----
AL1 begin:
[10.0, 11.0, 12.0, 13.0]
AL1 after index replaceAll($):
[100.0, 110.0, 120.0, 130.0]
original array:
[10.0, 11.0, 12.0, 13.0]
*/

//--------------------------------------------------

// import java.util.function.Predicate;
/*
interface Predicate<T> {
   boolean test(T t);
   ...
}
public boolean removeIf(Predicate<? super E> filter)
Returns true if any elements were removed
*/

   static boolean isHigh(Float x) {
      return x>12f;
   }

   static void testRemoveIf() {
      System.out.println("\n --- testRemoveIf: removeIf by passive iterator ----");
      var L= List.<Float>of(10f, 11f, 12f, 13f, 14f, 15f);
      var AL1= new ArrayList<Float>(L);
      System.out.println("AL1 begin: \n"+AL1);
      Predicate<Float> mtdRef= TestAL_callback::isHigh; 
      AL1.removeIf(mtdRef);
      System.out.println("AL1 after removeIf(mtdRef): \n"+AL1);
      System.out.println("---");

      var AL2= new ArrayList<Float>(L);
      System.out.println("AL2 begin: \n"+AL2);
      Predicate<Float> lambdaExp= x->(x>12f) ;
      AL1.removeIf(lambdaExp);
      System.out.println("AL2 after removeIf(lambdaExp): \n"
                         +AL1);
      System.out.println();
   }
/*
 --- testRemoveIf: removeIf by passive iterator ----
AL1 begin:
[10.0, 11.0, 12.0, 13.0, 14.0, 15.0]
AL1 after removeIf(mtdRef):
[10.0, 11.0, 12.0]
---
AL2 begin:
[10.0, 11.0, 12.0, 13.0, 14.0, 15.0]
AL2 after removeIf(lambdaExp):
[10.0, 11.0, 12.0]
*/

   static void testRemoveIf_actI() {
      System.out.println("\n --- testRemoveIf_actI: removeIf by active iterator ----");
      var L= List.<Float>of(10f, 11f, 12f, 13f, 14f, 15f);
      var AL1= new ArrayList<Float>(L);
      System.out.println("AL1 begin: \n"+AL1);
   // Predicate<Float> mtdRef= TestAL_callback::isHigh; 
   // AL1.removeIf(mtdRef);
      Iterator<Float> itr= AL1.iterator();
      while(itr.hasNext()) {
         Float x= itr.next();
      // if(TestAL_callback.isHigh(x)) {  
         if(x>12f) {  
            itr.remove();
         }  
      } 
      System.out.println("AL1 after removeIf(mtdRef): \n"+AL1);
      System.out.println();
   }
/*
 --- testRemoveIf_actI: removeIf by active iterator ----
AL1 begin:
[10.0, 11.0, 12.0, 13.0, 14.0, 15.0]
AL1 after removeIf(mtdRef):
[10.0, 11.0, 12.0]
*/

   static void testRemoveIf_idx() {
      System.out.println("\n --- testRemoveIf_idx: removeIf by index ----");
      var L= List.<Float>of(10f, 11f, 12f, 13f, 14f, 15f);
      var AL1= new ArrayList<Float>(L);
      System.out.println("AL1 begin: \n"+AL1);
      Predicate<Float> mtdRef= TestAL_callback::isHigh; 
   // AL1.removeIf(mtdRef);
      final int S= AL1.size();
      int i=0; 
      while(i<AL1.size()) {  // repeat evaluate AL1.size()
         Float x= AL1.get(i);
         if(x>12f) {  
            AL1.remove(i);  // reuse i in the nect loop
         }  
         else {  i++;  } 
      } 
      System.out.println("AL1 after removeIf: \n"+AL1);
      System.out.println();
   }
/* 
 --- testRemoveIf_idx: removeIf by index ----
AL1 begin:
[10.0, 11.0, 12.0, 13.0, 14.0, 15.0]
AL1 after removeIf:
[10.0, 11.0, 12.0] 
*/


   public static void main(String[] dummy){
      testRW();        testRW_actI();   
                       testRW_idx();
      testRead();      testRead_actI();   
                       testRead_idxI();
      testRemoveIf();  testRemoveIf_actI();   
                       testRemoveIf_idx();
   }

}
