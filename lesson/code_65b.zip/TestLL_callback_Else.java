import java.util.List;
import java.util.LinkedList;
import java.util.Iterator;
import java.util.ListIterator;
import java.util.function.UnaryOperator;
import java.util.function.Consumer;
import java.util.function.Predicate;

// access test
public class TestLL_callback_Else {


   public static <E> void myForEach(
      LinkedList<E> L, Consumer<? super E> axn
   ) {
      Iterator<E> itr= L.iterator();
      while(itr.hasNext()) {
         E x= itr.next();
         axn.accept(x);
      } 
   }

   static void test_myForEach() {
      System.out.println("\n --- test_myForEach ----");
      Float[] A1= { 10f, 11f, 12f, 13f, 14f };  // auto box
      var AL1= new LinkedList<Float>(List.<Float>of(A1));
      System.out.println("AL1: "+AL1);
      myForEach(AL1, x->{ System.out.print("("+x+") "); } );
      System.out.println();
   }
/*
 --- test_myForEach ----
AL1: [10.0, 11.0, 12.0, 13.0, 14.0]
(10.0) (11.0) (12.0) (13.0) (14.0)
*/

   public static <E> void myReplaceAll(
      LinkedList<E> L, UnaryOperator<E> opr
   ) {
      ListIterator<E> itr= L.<Float>listIterator();
      while(itr.hasNext()) {
         E x= itr.next();
         E y= opr.apply(x);
         itr.set(y);
      } 
   }

   static void test_myReplaceAll() {
      System.out.println("\n --- test_myReplaceAll  ----");
      Float[] A={ 10f, 11f, 12f, 13f };
      var L= java.util.List.<Float>of(A);
      var LL2= new LinkedList<Float>(L);
      System.out.println("LL2 begin: \n"+LL2);
      UnaryOperator<Float> lambdaExp= (x->10*x);
      LL2.replaceAll(lambdaExp);  
      System.out.println("LL2 after replaceAll(lambdaExp): \n"+LL2);
      System.out.println("original array: "+java.util.Arrays.toString(A));
   }
/*
 --- test_myReplaceAll  ----
LL2 begin:
[10.0, 11.0, 12.0, 13.0]
LL2 after replaceAll(lambdaExp):
[100.0, 110.0, 120.0, 130.0]
original array: [10.0, 11.0, 12.0, 13.0]
*/


   public static <E> boolean myRemoveIf(
      LinkedList<E> L, Predicate<? super E> filter
   ) {
      boolean removed= false;
      Iterator<E> itr= L.iterator();
      while(itr.hasNext()) {
         E x= itr.next();
         if(filter.test(x)) {  
            itr.remove();
            removed= true;
         }  
      } 
      return removed;
   }

   static void test_myRemoveIf() {
      System.out.println("\n --- test_myRemoveIf ----");
      var L= List.<Float>of(9f, 10f, 11f, 8f, 13f, 7f, 15f);
      var LL1= new LinkedList<Float>(L);
      System.out.println("LL1 begin: \n"+LL1);
      Predicate<Float> lambdaExp= x->(x<10f) ;
      myRemoveIf(LL1,lambdaExp);
      System.out.println("after myRemoveIf(LL1,lambdaExp): \nLL1:"
                         +LL1);
      System.out.println();
   }
/*
 --- test_myRemoveIf ----
LL1 begin:
[9.0, 10.0, 11.0, 8.0, 13.0, 7.0, 15.0]
after myRemoveIf(LL1,lambdaExp):
LL1:[10.0, 11.0, 13.0, 15.0]
*/


   static void testRemoveIfe_actI() {
      System.out.println("\n --- testRemoveIfe_actI: removeIf by active iterator ----");
      var L= List.<Float>of(10f, 10f, 11f, 12f, 12f, 12f, 13f);
      var LL1= new LinkedList<Float>(L);
      System.out.println("LL1 begin: \n"+LL1);
      Float old_x=null; 
      Iterator<Float> itr= LL1.iterator();
      while(itr.hasNext()) {
         Float x= itr.next();
         if(x.equals(old_x)) {  
            itr.remove();
         }  
         else {
            old_x= x;
         }
      } 
      System.out.println("LL1 after removeIf(mtdRef): \n"+LL1);
      System.out.println();
   }
/*
 --- testRemoveIfe_actI: removeIf by active iterator ----
LL1 begin:
[10.0, 10.0, 11.0, 12.0, 12.0, 12.0, 13.0]
LL1 after removeIf(mtdRef):
[10.0, 11.0, 12.0, 13.0]
*/


   static class Wrap_F {  // AtomicReference
      Float v;
      public Wrap_F(Float v0) {   this.v= v0;  }
   }

   static void testRemoveIfe() {
      System.out.println("\n --- testRemoveIfe: by passive iterator ----");
      var L= List.<Float>of(10f, 10f, 11f, 12f, 12f, 12f, 13f);
      var LL1= new LinkedList<Float>(L);
      System.out.println("LL1 begin: \n"+LL1);
      Float old_x=null;   
         //: Gemi: lambda may be sent to another thread by passive iterator
      Wrap_F old_x_wrap= new Wrap_F(old_x);
   // myRemoveIf(LL1, 
      LL1.removeIf( 
                x->{
                // if(x.equals(old_x)) {  
                   if(x.equals(old_x_wrap.v)) {  
                      return true;
                   }  
                   else {
                   // old_x= x;
                   //  // error: local variables referenced 
                   //  //        from a lambdaExp must be effectively final     
                      old_x_wrap.v= x;
                      return false;
                   }
                } 
      );
      System.out.println("LL1 after removeIf(mtdRef): \n"+LL1);
      System.out.println();
   }

   static void testRemoveIfe_Gemi() {
      System.out.println("\n --- testRemoveIfe_Gemi: by passive iterator ----");
      var L= List.<Float>of(10f, 10f, 11f, 12f, 12f, 12f, 13f);
      var LL1= new LinkedList<Float>(L);
      System.out.println("LL1 begin: \n"+LL1);
      LL1.removeIf( 
         new Predicate<Float>(){
             Float old_x= null;
             @Override
             public boolean test(Float x) {
                if(x.equals(old_x)) {  
                   return true;
                }  
                else {
                   old_x= x;
                   return false;
                }
             }
         }   
      );
      System.out.println("LL1 after removeIf(mtdRef): \n"+LL1);
      System.out.println();
   }


 //--------------------------------------------

   public static <E> boolean addIf(
      LinkedList<E> L, Predicate<? super E> filter, E nx
   ) {
      boolean added= false;
      ListIterator<E> itr= L.listIterator();
      while(itr.hasNext()) {
         E x= itr.next();
         if(filter.test(x)) {  
            itr.add(nx);
            added= true;
         }  
      } 
      return added;
   }

   static void testAddIf() {
      System.out.println("\n --- testAddIf: by passive iterator ----");
      var L= List.<Float>of(5f, 10f, 6f, 11f, 12f, 7f, 12f);
      var LL1= new LinkedList<Float>(L);
      System.out.println("LL1 begin: \n"+LL1);
      addIf( LL1, x->(x<10f), 99.9f );
      System.out.println("LL1 after removeIf(mtdRef): \n"+LL1);
      System.out.println();
   }
/*
 --- testAddIf: by passive iterator ----
LL1 begin:
[5.0, 10.0, 6.0, 11.0, 12.0, 7.0, 12.0]
LL1 after removeIf(mtdRef):
[5.0, 99.9, 10.0, 6.0, 99.9, 11.0, 12.0, 7.0, 99.9, 12.0]
*/


   public static <E> boolean setIf(
      LinkedList<E> L, Predicate<? super E> filter, E nx
   ) {
      boolean added= false;
      ListIterator<E> itr= L.listIterator();
      while(itr.hasNext()) {
         E x= itr.next();
         if(filter.test(x)) {  
            itr.set(nx);
            added= true;
         }  
      } 
      return added;
   }
   static void testSetIf() {
      System.out.println("\n --- testSetIf: by passive iterator ----");
      var L= List.<Float>of(5f, 10f, 6f, 11f, 12f, 7f, 12f);
      var LL1= new LinkedList<Float>(L);
      System.out.println("LL1 begin: \n"+LL1);
      setIf( LL1, x->(x<10f), -1f );
      System.out.println("LL1 after removeIf(mtdRef): \n"+LL1);
      System.out.println();
   }
/*
 --- testSetIf: by passive iterator ----
LL1 begin:
[5.0, 10.0, 6.0, 11.0, 12.0, 7.0, 12.0]
LL1 after removeIf(mtdRef):
[-1.0, 10.0, -1.0, 11.0, 12.0, -1.0, 12.0]
*/

   public static void main(String[] dummy){
      test_myForEach();
      test_myReplaceAll();
      test_myRemoveIf();

      testRemoveIfe_actI();  
      testRemoveIfe();
      testRemoveIfe_Gemi();
      
      testAddIf();
      testSetIf();
   }


}