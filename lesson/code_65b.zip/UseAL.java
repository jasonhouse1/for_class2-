import java.util.List;
import java.util.LinkedList;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.ListIterator;


public class UseAL {

 //------------------------------------------

   static void allM10_AL() {
      System.out.println("\n --- allM10_AL() --- ");
      Float[] A1= {  5.0f, 5.1f, 5.2f, 5.3f, 5.4f };
      var L1= new ArrayList<Float>( List.of(A1) );
      System.out.println("L1: "+L1);
   // allM10(L1);
      int s= L1.size(); 
      for(int i=0; i<s; i++) {
         L1.set(i, L1.get(i)*10);  
      }
      System.out.println("L1: "+L1);
   }
/*
 --- test_allM10_LL() ---
L1: [5.0, 5.1, 5.2, 5.3, 5.4]
L1: [50.0, 51.0, 52.0, 53.0, 54.0]
*/

   static <E> void ROR_ver1(ArrayList<E> L) {
      int s= L.size();
      if(s<=0) return;      
      E last= L.get(s-1);  
      for(int i=s-1; i>=1; i--) {
         L.set(i, L.get(i-1));  
      } 
      L.set(0, last);
   }
   static <E> void ROR_ver2(ArrayList<E> L) {
      int s= L.size();
      if(s<=0) return;      
      E last= L.get(s-1);  
      for(int i=s-2; i>=0; i--) {
         L.set(i+1, L.get(i));  
      } 
      L.set(0, last);
   }
   static <E> void ROR(ArrayList<E> L) {  
      ROR_ver2(L);  
   }
   static void test_ROR_AL() {
      System.out.println("\n --- test_ROR_AL() --- ");
      Float[] A1= {  5.0f, 5.1f, 5.2f, 5.3f, 5.4f };
      var L1= new ArrayList<Float>( List.of(A1) );
      System.out.println("L1: "+L1);
      ROR(L1);
      System.out.println("L1: "+L1);
   }
/*
 --- test_ROR_AL() ---
L1: [5.0, 5.1, 5.2, 5.3, 5.4]
L1: [5.4, 5.0, 5.1, 5.2, 5.3]
*/


   public static void main(String[] dummy) {
      allM10_AL();
      test_ROR_AL();
      System.out.println("\n all OK");
   }

}