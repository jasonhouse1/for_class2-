import java.util.LinkedList;
import java.util.List;
import java.util.Arrays;
import java.util.Comparator;

public class TestLL_sort {

// public void sort(Comparator<? super E> c)
// java.util.Comparator<T> 是函數介面, 指向形如 int compare(T o1,T o2) 的函數. 


   static int cmpY(XY v1, XY v2) {
      // if(v1.y<v2.y) return -1;
      // else if(v1.y==v2.y) return 0;
      // else return 1;
      return (v1.y<v2.y) ? -1 : (v1.y==v2.y) ? 0 : 1 ;  // right associativity
      // return (int)(Math.signum(v1-v2));
   }

   static void test1() {
      System.out.println("\n --- test1: by method reference  ----");

      XY[] b1= { new XY(0.0f,6.2f),  new XY(2.0f,5.2f), 
                 new XY(4.0f,4.2f),  new XY(4.0f,3.2f) };
      LinkedList<XY> LL1= new LinkedList<XY>(List.of(b1)); 
      System.out.println("LL1: "+LL1);
      System.out.println("b1:  "+Arrays.toString(b1));

   // LL1.sort(Test_sortObjA_cmptor::compareY);
      LL1.sort(TestLL_sort::cmpY);
      System.out.println("after compareY,\nAL1: "+LL1);
      System.out.println("b1:  "+Arrays.toString(b1));

      LL1.sort(Test_sortObjA_cmptor::compareX);
      System.out.println("after compareX,\nAL1: "+LL1);
      System.out.println("b1:  "+Arrays.toString(b1));
   }
/*
 --- test1: by method reference  ----
LL1: [(0.0,6.2), (2.0,5.2), (4.0,4.2), (4.0,3.2)]
b1:  [(0.0,6.2), (2.0,5.2), (4.0,4.2), (4.0,3.2)]
after compareY,
LL1: [(4.0,3.2), (4.0,4.2), (2.0,5.2), (0.0,6.2)]
b1:  [(0.0,6.2), (2.0,5.2), (4.0,4.2), (4.0,3.2)]
after compareX,
LL1: [(0.0,6.2), (2.0,5.2), (4.0,3.2), (4.0,4.2)]      ******
b1:  [(0.0,6.2), (2.0,5.2), (4.0,4.2), (4.0,3.2)]
*/

   static void test2() {
      System.out.println("\n --- test2: by lambda expression ----");

      LinkedList<Float> LL1= 
         new LinkedList<Float>(List.of(0.7f, 0.2f, 0.3f, 0.9f, 0.1f)); 
      System.out.println("LL1: "+LL1);

      LL1.sort( (x, y)->(x<y)? -1 : ((float)x==(float)y)? 0: 1  );
      System.out.println("after sort,\nAL1: "+LL1);
   }
/*
 --- test2: by lambda expression ----
LL1: [0.7, 0.2, 0.3, 0.9, 0.1]
after sort,
LL1: [0.1, 0.2, 0.3, 0.7, 0.9]
*/

   static void test3() {
      System.out.println("\n --- test3: natural order ----");

      LinkedList<Float> LL1= 
         new LinkedList<Float>(List.of(0.7f, 0.2f, 0.3f, 0.9f, 0.1f)); 
      System.out.println("LL1: "+LL1);

   // LL1.sort( null );  // less reabable
   // java.util.Collections.sort(LL1);  // older tool
      LL1.sort( java.util.Comparator.naturalOrder() );
      System.out.println("after sorted by naturalOrder,\nAL1: "+LL1);

      LL1.sort( java.util.Comparator.reverseOrder() );
      System.out.println("after sorted by reverseOrder(),\nAL1: "+LL1);
   }
/*
 --- test3: natural order ----
LL1: [0.7, 0.2, 0.3, 0.9, 0.1]
after sorted by naturalOrder,
LL1: [0.1, 0.2, 0.3, 0.7, 0.9]
after sorted by reverseOrder(),
LL1: [0.9, 0.7, 0.3, 0.2, 0.1]
*/

   static void test4() {
      System.out.println("\n --- test4: compare with null ----");

      LinkedList<Float> LL1;
      try {
         LL1= new LinkedList<Float>(  
                 List.of(0.7f, 0.2f, 0.3f, null, 0.9f, 0.1f)
              );
      }
      catch(java.lang.NullPointerException xpt) {
         System.out.println("catch NullPointerException on ctor"); 
      } 
      LL1= new LinkedList<Float>();
      {
         LL1.add(0.7f);  LL1.add(0.2f);  LL1.add(0.3f);
         LL1.add(null);  LL1.add(0.9f);  LL1.add(0.1f);
      }
      System.out.println("LL1: "+LL1);
      try { 
         LL1.sort( java.util.Comparator.naturalOrder() ); 
      }
      catch(java.lang.NullPointerException xpt) {
         System.out.println("catch NullPointerException on sort"); 
      } 
      LL1.sort( Comparator.nullsFirst(Comparator.naturalOrder()) ); // cause .NullPointerException
      System.out.println("after sorted by nullsFirst,\nAL1: "+LL1);

      LL1.sort( Comparator.nullsLast(Comparator.naturalOrder()) ); // cause .NullPointerException
      System.out.println("after sorted by nullsLast,\nAL1: "+LL1);
   }
/*
 --- test4: compare with null ----
catch NullPointerException on ctor
LL1: [0.7, 0.2, 0.3, null, 0.9, 0.1]
catch NullPointerException on sort
after sorted by nullsFirst,
LL1: [null, 0.1, 0.2, 0.3, 0.7, 0.9]
after sorted by nullsLast,
LL1: [0.1, 0.2, 0.3, 0.7, 0.9, null]
*/

   static void test5() {
      System.out.println("\n --- test5: sort a portion ----");
   // move to TestLL_subList   
   }

   public static void main(String[] dummy){
      test1();
      test2();
      test3();
      test4();
   // test5();
      System.out.println("\n all OK" ); 

   }

}
