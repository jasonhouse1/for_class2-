import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.LinkedList;
import java.util.Comparator;

// use class XY
// use comparators in class Test_sortObjA_cmptor 

/*
@FunctionalInterface interface Comparator<T> {
   public int compareTo(T o1, T o2);
// ...
}
public static <T extends Comparable<? super T>> 
              void sort(List<T> list)
public static <T> void sort(List<T> list, Comparator<T> c)
*/ 
class TestLL_sortColl_cmptor {

   static void test_ptr_sort() {
      System.out.println("\n --- test_ptr_sort ---");  

      XY[] b1= { new XY(0.0f,6.2f),  new XY(2.0f,5.2f), 
                 new XY(4.0f,4.2f),  new XY(8.0f,3.2f) };
   // System.out.println("b1: "+Arrays.toString(b1));  
      var LL1= new LinkedList<XY>(List.of(b1)); 
      System.out.println("begin,\n LL1: "+LL1);

      try{
   // Collections.sort(LL1);   // compile Error 
      Collections.sort(LL1, null); 
      }
      catch(java.lang.ClassCastException xpt) {
         System.out.println("... catched:  \n"+xpt);
      }

      Collections.<XY>sort(LL1, Test_sortObjA_cmptor::compareX); 
                                      // explicitly use XY for T
      System.out.println("after compareX,\n LL1: "+LL1);

      Collections.sort(LL1, Test_sortObjA_cmptor::compareY); 
                                      // implicitly use XY for T
      System.out.println("after compareY,\n LL1: "+LL1);

      Collections.sort(LL1, Test_sortObjA_cmptor::compareS); 
                                      // implicitly use XY for T 
      System.out.println("after compareS,\n LL1: "+LL1);

   }
/*
 --- test_ptr_sort ---
begin,
 LL1: [(0.0,6.2), (2.0,5.2), (4.0,4.2), (8.0,3.2)]
... catched:
java.lang.ClassCastException: class XY cannot be cast to class java.lang.Comparable (XY is in unnamed module of loader 'app'; java.lang.Comparable is in module java.base of loader 'bootstrap')
after compareX,
 LL1: [(0.0,6.2), (2.0,5.2), (4.0,4.2), (8.0,3.2)]
after compareY,
 LL1: [(8.0,3.2), (4.0,4.2), (2.0,5.2), (0.0,6.2)]
after compareS,
 LL1: [(0.0,6.2), (2.0,5.2), (4.0,4.2), (8.0,3.2)]
*/

// test public static <T> int binarySearch(List<T> list, T key, Comparator<T> c)
  static void test_ptr_binarySearch() {
      System.out.println("\n --- test_ptr_binarySearch ---");  

      XY[] b1= { new XY(0.0f,6.2f),  new XY(2.0f,5.2f), 
                 new XY(4.0f,4.2f),  new XY(6.0f,3.2f) };
   // System.out.println("b1: "+Arrays.toString(b1));  
      var LL1= new LinkedList<XY>(List.of(b1)); 
      System.out.println("begin,\n LL1: "+LL1);

      Collections.sort(LL1, Test_sortObjA_cmptor::compareY); 
      System.out.println("after compareY,\n LL1: "+LL1);

      XY key1= new XY(3.0f, 4.2f);
      System.out.println(
         "binarySearch "+ key1+" by Test_Sort::compareY: "
         +Collections.binarySearch(LL1, key1, Test_sortObjA_cmptor::compareY)
      );

      XY key2= new XY(2.0f, 3.2f);
      System.out.println(
         "binarySearch "+ key2+" by Test_Sort::compareY: "
         +Collections.binarySearch(LL1, key2, Test_sortObjA_cmptor::compareY)
      );

      XY key3= new XY(2.0f, 5.0f);
      System.out.println(
         "binarySearch "+ key3+" by Test_Sort::compareY: "
         +Collections.binarySearch(LL1, key3, Test_sortObjA_cmptor::compareY)
      );

   }
/*
 --- test_ptr_binarySearch ---
begin,
 LL1: [(0.0,6.2), (2.0,5.2), (4.0,4.2), (6.0,3.2)]
after compareY,
 LL1: [(6.0,3.2), (4.0,4.2), (2.0,5.2), (0.0,6.2)]
binarySearch (3.0,4.2) by Test_Sort::compareY: 1
binarySearch (2.0,3.2) by Test_Sort::compareY: 0
binarySearch (2.0,5.0) by Test_Sort::compareY: -3
*/

// test public static &lt;T&gt; int binarySearch(List&lt;T&gt; list, T key)
  static void test_ptr_binarySearch_natural() {
      System.out.println("\n --- test_ptr_binarySearch_natural ---");  

      Float[] b1= { 6.2f, 5.2f, 4.2f, 3.2f };
   // System.out.println("b1: "+Arrays.toString(b1));  
      var LL1= new LinkedList<Float>(List.of(b1)); 
      System.out.println("begin,\n LL1: "+LL1);

      Collections.sort(LL1); 
      System.out.println("after sort by natural order,\n LL1: "+LL1);

      Float key1= 4.2f;  // auto box
      System.out.println(
         "binarySearch "+ key1+" by natural order: "
      // +Collections.binarySearch(LL1, key1)
         +Collections.binarySearch(LL1, key1, Comparator.naturalOrder())
      );

      Float key2= 3.2f;
      System.out.println(
         "binarySearch "+ key2+" by natural order: "
         +Collections.binarySearch(LL1, key2)
      );

      Float key3= 5.0f;
      System.out.println(
         "binarySearch "+ key3+" by natural order:"
         +Collections.binarySearch(LL1, key3)
      );

   }
/*
 --- test_ptr_binarySearch_natural ---
begin,
 LL1: [6.2, 5.2, 4.2, 3.2]
after sort by natural order,
 LL1: [3.2, 4.2, 5.2, 6.2]
binarySearch 4.2 by natural order: 1
binarySearch 3.2 by natural order: 0
binarySearch 5.0 by natural order:-3
*/

  static void test_ptr_binarySearch_reverse() {
      System.out.println("\n --- test_ptr_binarySearch_reverse ---");  

      Float[] b1= { 6.2f, 5.2f, 4.2f, 3.2f };
   // System.out.println("b1: "+Arrays.toString(b1));  
      var LL1= new LinkedList<Float>(List.of(b1)); 
      System.out.println("begin,\n LL1: "+LL1);

      Collections.sort(LL1); 
      System.out.println("after sort by natural order,\n LL1: "+LL1);

      Collections.sort(LL1, Comparator.reverseOrder()); 
      System.out.println("after sort by reverse order,\n LL1: "+LL1);

      Float key1= 4.2f;  // auto box
      System.out.println(
         "binarySearch "+ key1+" by reverse order: "
      // +Collections.binarySearch(LL1, key1)
         +Collections.binarySearch(LL1, key1, Comparator.reverseOrder())
      );

      Float key2= 3.2f;
      System.out.println(
         "binarySearch "+ key2+" by reverse order: "
         +Collections.binarySearch(LL1, key2, Comparator.reverseOrder())
      );

      Float key3= 5.0f;
      System.out.println(
         "binarySearch "+ key3+" by reverse order:"
         +Collections.binarySearch(LL1, key3, Comparator.reverseOrder())
      );
   }
/*
 --- test_ptr_binarySearch_reverse ---
begin,
 LL1: [6.2, 5.2, 4.2, 3.2]
after sort by natural order,
 LL1: [3.2, 4.2, 5.2, 6.2]
after sort by reverse order,
 LL1: [6.2, 5.2, 4.2, 3.2]
binarySearch 4.2 by reverse order: 2
binarySearch 3.2 by reverse order: 3
binarySearch 5.0 by reverse order:-3
*/


   public static void main(String[] dummy) {
      test_ptr_sort();
      test_ptr_binarySearch();
      test_ptr_binarySearch_natural();
      test_ptr_binarySearch_reverse();
      System.out.println("\nall OK");
   }

}

