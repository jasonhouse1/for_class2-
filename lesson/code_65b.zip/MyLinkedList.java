import java.util.List;
import java.util.LinkedList;
import java.util.Collection; 
import java.util.ListIterator;

/*
public class LinkedList {

   public E get(int idx) 
     // Returns: the element at the specified position

   public E set(int idx, E elm) 
     // Returns: the element previously at the specified position

   public boolean contains(Object o)
    //  Returns: true if this list contains the specified element
   public int indexOf(Object o)
    //  Returns: the index of the first occurrence of the specified element 
                 or -1 if this list does not contain the element
   public int lastIndexOf(Object o)
    //  Returns: the index of the last occurrence of the specified element in this list 
    //           or -1 if this list does not contain the element

  //--------

   public void add(int idx, E elm)

   public E remove(int idx) 
   //  return the element removed from the list
   public boolean remove(Object o)
   //  Return true if this list contained the specified element

   protected void removeRange(int fromIdx, int toIdx)

   public boolean remove(Object obj)  只刪最前一格
   public boolean removeAll(Collection<?> c)
     // Returns: true if this list changed as a result of the call
   public boolean retainAll(Collection<?> c)
     // Returns: true if this list changed as a result of the call
}

interface 
public Collection {
  boolean contains(Object o)
}

*/

//
// simulate instance methods of LinkedList in client code
//
public class MyLinkedList {

// private static boolean isElementIndex(int idx, int sz) {
//    return (0<=idx && idx<sz);
// }
   private static void checklementIndex(int idx, int sz) {
      if(! (0<=idx && idx<sz) ) {
          throw new IndexOutOfBoundsException(
             "(index: "+idx+", size: "+sz+")"
          );
      }
   }
// private static boolean isPositionIndex(int idx, int sz) {
//     return (0<=idx && idx <= sz);
// }
   private static void checkPositionIndex(int idx, int sz) {
      if(! (0<=idx && idx<=sz) ) {
          throw new IndexOutOfBoundsException(
             "(index: "+idx+", size: "+sz+")"
          );
      }
   }

//>>> toD
//   static <E> void gotoPos(ListIterator<E> itr, int idx) {
//      while(itr.nextIndex()<idx) {  itr.next(); }
//   }

   public static <E> 
   ListIterator<E> listIterator(LinkedList<E> LL, int idx) {
       final int sz= LL.size(); 
       checkPositionIndex(idx, sz);

       ListIterator<E> itr;
       if(idx < (sz/2) ) {
          itr= LL.listIterator();
          while(itr.nextIndex()<idx) {  itr.next();  }
       }     
       else {
          itr= LL.listIterator(sz);
          while(idx <= itr.previousIndex()) {  itr.previous();  }
       }
       return itr; 
    }


// implementing access methods

   public static <E> E get(LinkedList<E> LL, int idx) {
      final int sz= LL.size(); 
      checklementIndex(idx, sz);
   // var itr= LL.listIterator(0);
   // while(itr.nextIndex()<idx) {  itr.next(); }
      var itr= listIterator(LL, idx);
      E x= itr.next();
      return x; 
   }

   public static <E> E set(LinkedList<E> LL, int idx, E elm) {
      final int sz= LL.size(); 
      checklementIndex(idx, sz);
   // var itr= LL.listIterator(0);
   // while(itr.nextIndex()<idx) {  itr.next(); }
      var itr= listIterator(LL, idx);
      E x= itr.next();
      itr.set(elm); 
      return x; 
   }

   static <E> int lastIndexOf(LinkedList<E> LL, Object o) {
      var itr= LL.listIterator(LL.size());
      while(itr.hasPrevious()) {
         var x= itr.previous();
         if(x.equals(o)) return itr.nextIndex();
      }
      return -1;  
   }

   static <E> int indexOf(LinkedList<E> LL, Object o) {
   // return LL.indexOf(o);
      var itr= LL.listIterator(0);
      while(itr.hasNext()) {
         var x= itr.next();
         if(x.equals(o)) return itr.previousIndex();
      }
      return -1;  
   }

   static <E> boolean contains(LinkedList<E> LL, Object o) {
   // return LL.contains(o);
      var itr= LL.listIterator(0);
      while(itr.hasNext()) {
         var x= itr.next();
         if(x.equals(o)) return true;
      }
      return false;  
   }


// -----------------------------------------
// implementing restruct methods

   public static <E> void add(LinkedList<E> LL, int idx, E elm) {
      var itr= listIterator(LL, idx);  
            //: checkPositionIndex in function
      itr.add(elm);
   } // Note: in java src use node(int idx)


   public static <E> E remove(LinkedList<E> LL, int idx) {
      final int sz= LL.size();
      checklementIndex(idx, sz);
      var itr= listIterator(LL, idx); //: checkPositionIndex in function
      if(itr.nextIndex()==sz) {
         throw new IndexOutOfBoundsException(
            "(index: "+idx+", size: "+sz+")"
         );
      }
      E ans= itr.next();   itr.remove();
      return ans; 
   }

   public static <E> void removeRange(
      LinkedList<E> LL, int frI, int toI
   ) {
      final int sz= LL.size();
      if(! (0<=frI && frI<sz && toI<=sz && frI<=toI ) ) {
      // the condition is subject to the API of ArrayList
         throw new IndexOutOfBoundsException(
                  "(frI: "+frI+", toI: "+toI+" size: "+sz+")"
               );
      } 
   // var itr= LL.listIterator();  // Iterator no nextIndex()
   // while(itr.nextIndex()<frI) {  itr.next(); }
      var itr= listIterator(LL, frI);
      final int delSize= toI-frI;   // 3-1=2; 
      for(int i=1; i<=delSize; i++) {
         itr.next();  itr.remove();
      }
   } // JDK implements in AbstractList.java

   public static <E> boolean remove(
      LinkedList<E> LL, Object obj
   ) {
      var itr= LL.listIterator();
      while(itr.hasNext()) {
         E x= itr.next(); 
         if(x.equals(obj)) {
            itr.remove();  return true; 
         }  
      }
      return false;
   }

   public static <E> boolean removeAll(
      LinkedList<E> LL, java.util.Collection<?> coll
   ) {
      boolean changed= false;
      var itr= LL.listIterator();
      while(itr.hasNext()) {
         E x= itr.next();
         if(coll.contains(x)) { 
            itr.remove();  changed= true;
         }
      }
      return changed;
   }

   public static <E> boolean retainAll(
      LinkedList<E> LL, java.util.Collection<?> coll
   ) {
      boolean changed= false;
      var itr= LL.listIterator();
      while(itr.hasNext()) {
         E x= itr.next();
     //D System.out.print("@"+x);
         if(! coll.contains(x)) { 
     //D System.out.println(" toD");
            itr.remove();  changed= true;
         }
      }
      return changed;
   }

//---------------------------------------------

   public static void main(String[] dummy) {
      Test_MyLinkedList.main(dummy);
      System.out.println("\n all OK");
   }
   

} 