import java.util.LinkedList;
import java.util.Iterator;

public class TestLL_ForEach {

   static void demoArray() {
      System.out.println("\n --- demoArray ---"); 
      float[] A= { 0.1f, 0.2f, 0.3f, 0.4f, 0.5f };
      System.out.println("A: "+java.util.Arrays.toString(A)); 
      for(float x: A) {
         System.out.print(x+"\t"); 
      }  
      System.out.println(); 

   //[ translation of the preceeding for
      for(int i=0; i<A.length; i++) {
         float x= A[i];
         System.out.print(x+"\t"); 
      }
      System.out.println(); 
   //]

      for(float x: A) {
         x+=5;    //: each x is a copy of A[i]    !!!
         System.out.print(x+"\t"); 
      }  
      System.out.println(); 
      System.out.println("A: "+java.util.Arrays.toString(A)
                                        +" ***沒改變"); 
      
      float S= 0f;
      for(float x: A) {   S+= x;  } 
      System.out.println("S: "+S); 
      System.out.println();  

   }
/*
 --- demoArray ---
A: [0.1, 0.2, 0.3, 0.4, 0.5]
0.1     0.2     0.3     0.4     0.5
0.1     0.2     0.3     0.4     0.5
5.1     5.2     5.3     5.4     5.5
A: [0.1, 0.2, 0.3, 0.4, 0.5] ***沒改變
S: 1.5
*/

   static void demoLinkedList_F() {
      System.out.println("\n --- demoLinkedList_F ---"); 
      LinkedList<Float> LL= 
         new LinkedList<Float>( 
            java.util.List.of(0.1f, 0.2f, 0.3f, 0.4f, 0.5f)
         );
      System.out.println("LL: "+LL); 

      for(float x: LL) {
         System.out.print(x+"\t"); 
      }  
      System.out.println(); 

   //[ translation of the preceeding for
      for(Iterator<Float> itr= LL.iterator(); itr.hasNext();   ) {
         Float x= itr.next();
         System.out.print(x+"\t"); 
      } 
   //]
      System.out.println(); 

      for(float x: LL) { //: each x is a copy 
         x+=5;   
      // x= x+5;    
         System.out.print(x+"\t"); 
      }  
/*
   //[ translation of the preceeding for
      for(Iterator<Float> itr= LL.iterator(); itr.hasNext();   ) {
         Float x= itr.next();
         x+=5;
      // x=x+5;    
      // x=x.valueOf(x.floatValue()+5);   
         System.out.print(x+"\t"); 
      } 
   //]
*/
      System.out.println(); 
      System.out.println("LL: "+LL+" ***沒改變"); 

      float S= 0f;
      for(float x: LL) {   S+= x;  } 
      System.out.println("S: "+S); 

   }
/*
 --- demoLinkedList_F ---
LL: [0.1, 0.2, 0.3, 0.4, 0.5]
0.1     0.2     0.3     0.4     0.5
0.1     0.2     0.3     0.4     0.5
5.1     5.2     5.3     5.4     5.5
LL: [0.1, 0.2, 0.3, 0.4, 0.5] ***沒改變
S: 1.5
*/

   static void demoArrayList_Wf() {
      System.out.println("\n --- demoArrayList_Wf ---"); 
      Wrap_f[] a= {
         new Wrap_f(0.1f), new Wrap_f(0.2f), new Wrap_f(0.3f),
         new Wrap_f(0.4f), new Wrap_f(0.5f),
      };
      LinkedList<Wrap_f> LL= 
         new LinkedList<Wrap_f>( 
            java.util.List.of(a)
         );
      System.out.println("LL: "+LL); 

      for(Wrap_f x: LL) {
         System.out.print(x+"\t"); 
      }  
      System.out.println(); 

   //[ translation of the preceeding for
      for(Iterator<Wrap_f> itr= LL.iterator(); itr.hasNext();   ) {
         Wrap_f x= itr.next();
         System.out.print(x+"\t"); 
      } 
   //]
      System.out.println(); 

      for(Wrap_f x: LL) {
         x.v+=5;    //: each x is a copy 
         System.out.print(x+"\t"); 
      }  
      System.out.println(); 

      System.out.println("LL: "+LL+" ***外掛物件改變"); 
      System.out.println("a: "+java.util.Arrays.toString(a)
                          +" ***外掛物件改變"); 

      float S= 0f;
      for(Wrap_f x: LL) {   S+= x.v;  } 
      System.out.println("S: "+S); 

   }
/*
 --- demoArrayList_Wf ---
LL: [0.1, 0.2, 0.3, 0.4, 0.5]
0.1     0.2     0.3     0.4     0.5
0.1     0.2     0.3     0.4     0.5
5.1     5.2     5.3     5.4     5.5
LL: [5.1, 5.2, 5.3, 5.4, 5.5] ***外掛物件改變
a: [5.1, 5.2, 5.3, 5.4, 5.5] ***外掛物件改變
S: 26.5
*/

   public static void main(String[] dummy) {
      demoArray();
      demoLinkedList_F();
      demoArrayList_Wf();
   }


} 