import java.util.List;
import java.util.LinkedList;
import java.util.Collection; 
import java.util.ListIterator;


//
// simulate instance methods of LinkedList in client code
//
public class Test_MyLinkedList {

//---------------------------------------------

   static String[] A= { "s0", "s1", "s2", "s3", "s4" };
   static final int lenA= A.length;

   static void test_get() {
      System.out.println("\n --- test_get  ----");
      LinkedList<String> LL1= 
         new LinkedList<String>(List.of(A)); 
      System.out.println("LL1: "+LL1);

      for(int i=0; i<lenA; i++) {
         String x= MyLinkedList.get(LL1, i);
         System.out.print("@"+i+": "+x+",  ");
      }
      System.out.println();
      try{ MyLinkedList.get(LL1, -1); }
      catch(IndexOutOfBoundsException xpt) {
         System.out.println("catch: "+xpt);
      }  
      try{ MyLinkedList.get(LL1, lenA); }
      catch(IndexOutOfBoundsException xpt) {
         System.out.println("catch: "+xpt);
      }  
   }
/*
 --- test_get  ----
LL1: [s0, s1, s2, s3, s4]
@0: s0,  @1: s1,  @2: s2,  @3: s3,  @4: s4,
catch: java.lang.IndexOutOfBoundsException: (index: -1, size: 5)
catch: java.lang.IndexOutOfBoundsException: (index: 5, size: 5)
*/

   static void test_set() {
      System.out.println("\n --- test_set  ----");
      LinkedList<String> LL1;
      for(int i=0; i<lenA; i++) {
         LL1= new LinkedList<String>(List.of(A)); 
         System.out.println("LL1: "+LL1);
         String x= MyLinkedList.set(LL1, i, "^^");
         System.out.println("@"+i+" : "+LL1 +", org "+x);
      }
      LL1= new LinkedList<String>(List.of(A)); 
      try{ MyLinkedList.set(LL1, -1, "^^"); }
      catch(IndexOutOfBoundsException xpt) {
         System.out.println("catch: "+xpt);
      }  
      try{ MyLinkedList.set(LL1, lenA, "^^"); }
      catch(IndexOutOfBoundsException xpt) {
         System.out.println("catch: "+xpt);
      }  
   }
/*
 --- test_set  ----
LL1: [s0, s1, s2, s3, s4]
@0 : [^^, s1, s2, s3, s4], org s0
LL1: [s0, s1, s2, s3, s4]
@1 : [s0, ^^, s2, s3, s4], org s1
LL1: [s0, s1, s2, s3, s4]
@2 : [s0, s1, ^^, s3, s4], org s2
LL1: [s0, s1, s2, s3, s4]
@3 : [s0, s1, s2, ^^, s4], org s3
LL1: [s0, s1, s2, s3, s4]
@4 : [s0, s1, s2, s3, ^^], org s4
catch: java.lang.IndexOutOfBoundsException: (index: -1, size: 5)
catch: java.lang.IndexOutOfBoundsException: (index: 5, size: 5)
*/

   static void test_add() {
      System.out.println("\n --- test_add  ----");
      LinkedList<String> LL1;
      for(int i=0; i<=lenA; i++) {
         LL1= new LinkedList<String>(List.of(A)); 
         System.out.println("LL1: "+LL1);
         MyLinkedList.add(LL1, i, "^^");
         System.out.println("@"+i+" : "+LL1);
      }
      LL1= new LinkedList<String>(List.of(A)); 
      try{ MyLinkedList.add(LL1, -1, "ZZ"); }
      catch(IndexOutOfBoundsException xpt) {
         System.out.println("catch: "+xpt);
      }  
      try{ MyLinkedList.add(LL1, lenA+1, "ZZ"); }
      catch(IndexOutOfBoundsException xpt) {
         System.out.println("catch: "+xpt);
      }  
   }
/*
 --- test_add  ----
LL1: [s0, s1, s2, s3, s4]
@0 : [^^, s0, s1, s2, s3, s4]
LL1: [s0, s1, s2, s3, s4]
@1 : [s0, ^^, s1, s2, s3, s4]
LL1: [s0, s1, s2, s3, s4]
@2 : [s0, s1, ^^, s2, s3, s4]
LL1: [s0, s1, s2, s3, s4]
@3 : [s0, s1, s2, ^^, s3, s4]
LL1: [s0, s1, s2, s3, s4]
@4 : [s0, s1, s2, s3, ^^, s4]
LL1: [s0, s1, s2, s3, s4]
@5 : [s0, s1, s2, s3, s4, ^^]
catch: java.lang.IndexOutOfBoundsException: (index: -1, size: 5)
catch: java.lang.IndexOutOfBoundsException: (index: 6, size: 5)
*/

   static void test_remove() {
      System.out.println("\n --- test_remove  ----");
      LinkedList<String> LL1;
      for(int i=0; i<lenA; i++) {
         LL1= new LinkedList<String>(List.of(A)); 
         System.out.println("LL1: "+LL1);
         String x= MyLinkedList.remove(LL1, i);
         System.out.println("@"+i+" : "+LL1 +", remove "+x);
      }
      LL1= new LinkedList<String>(List.of(A)); 
      try{ MyLinkedList.remove(LL1, -1); }
      catch(IndexOutOfBoundsException xpt) {
         System.out.println("catch: "+xpt);
      }  
      try{ MyLinkedList.remove(LL1, lenA); }
      catch(IndexOutOfBoundsException xpt) {
         System.out.println("catch: "+xpt);
      }  
   }
/*
 --- test_remove  ----
LL1: [s0, s1, s2, s3, s4]
@0 : [s1, s2, s3, s4], remove s0
LL1: [s0, s1, s2, s3, s4]
@1 : [s0, s2, s3, s4], remove s1
LL1: [s0, s1, s2, s3, s4]
@2 : [s0, s1, s3, s4], remove s2
LL1: [s0, s1, s2, s3, s4]
@3 : [s0, s1, s2, s4], remove s3
LL1: [s0, s1, s2, s3, s4]
@4 : [s0, s1, s2, s3], remove s4
catch: java.lang.IndexOutOfBoundsException: (index: -1, size: 5)
catch: java.lang.IndexOutOfBoundsException: (index: 5, size: 5)
*/

   static void test_removeRange() {
      System.out.println("\n --- test_removeRange  ----");
      LinkedList<String> LL1;
      for(int i=0; i<lenA; i++) {
         LL1= new LinkedList<String>(List.of(A)); 
         System.out.println("LL1: "+LL1);
         final int sz= LL1.size();
         int toI= i+2;  if(toI>sz) toI= sz;
         MyLinkedList.removeRange(LL1, i, toI);
         System.out.println("@"+i+" : "+LL1 );
      }
      LL1= new LinkedList<String>(List.of(A)); 
      try{ MyLinkedList.removeRange(LL1, -1, -1); }
      catch(IndexOutOfBoundsException xpt) {
         System.out.println("catch: "+xpt);
      }  
      try{ MyLinkedList.removeRange(LL1, lenA, lenA); }
      catch(IndexOutOfBoundsException xpt) {
         System.out.println("catch: "+xpt);
      }  
   }
/*
 --- test_removeRange  ----
LL1: [s0, s1, s2, s3, s4]
@0 : [s2, s3, s4]
LL1: [s0, s1, s2, s3, s4]
@1 : [s0, s3, s4]
LL1: [s0, s1, s2, s3, s4]
@2 : [s0, s1, s4]
LL1: [s0, s1, s2, s3, s4]
@3 : [s0, s1, s2]
LL1: [s0, s1, s2, s3, s4]
@4 : [s0, s1, s2, s3]
catch: java.lang.IndexOutOfBoundsException: (frI: -1, toI: -1 size: 5)
catch: java.lang.IndexOutOfBoundsException: (frI: 5, toI: 5 size: 5)
*/

   public static void main(String[] dummy) {
      test_get();
      test_set();
      test_add();
      test_remove();
      test_removeRange();
   }
   

} 