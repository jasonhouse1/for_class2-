import java.util.LinkedList;

// Test constructors, toString(), 

/*
Constructors of LinkedList
LinkedList()
LinkedList(Collection<? extends E> c)	
*/


public class TestLL_ctor {
   static void test1() {
      System.out.println("\n --- test1: init by add(E)  ----");
// public boolean add(E e), 
//    Return true (as specified by Collection.add(E))
//    in Collection, Return true if this collection changed as a result of the call
      LinkedList<String> LL1= new LinkedList<String>();
      LL1.add("aaa");
      System.out.println(LL1.toString());
      LL1.add(null);
      System.out.println(LL1.toString());
      LL1.add("cc");
      System.out.println(LL1.toString());
   // System.out.println(LL1);
   } 
/*
 --- test1: init by add(E)  ----
[aaa]
[aaa, null]
[aaa, null, cc]
*/

   static void test2() {
      System.out.println("\n --- test2: init in ctor  ----");
      String[] A1= { "aaa", "", "cc", };
   // String[] A1= new String[]{ "aaa", "", "cc",  );
      LinkedList<String> LL1= 
         new LinkedList<String>(java.util.List.of(A1));
         // cannot contains null
      System.out.println(LL1);

      LinkedList<String> LL2= 
         new LinkedList<String>(
            java.util.List.of(
               new String[]{ "aaa", "", "cc", }  // cannot contains null
            )
         );
         
      System.out.println(LL2);

      LinkedList<String> LL3= 
         new LinkedList<String>(
            java.util.List.of("aaa", "", "cc" )
         );
         // cannot contains null
      System.out.println(LL3);
   } 
/*
 --- test2: init in ctor  ----
[aaa, , cc]
[aaa, , cc]
[aaa, , cc]
*/


// void ensureCapacity(int minCapacity)

// Note: get, set 在本章稍後
   static void test3() {
      System.out.println("\n --- test3: mutable object  ----");
      Wrap_f[] A1= { new Wrap_f(10.1f), new Wrap_f(10.2f), new Wrap_f(10.3f) };
      LinkedList<Wrap_f> LL1= 
         new LinkedList<Wrap_f>(java.util.List.of(A1));
      System.out.println("LL1: "+LL1);
      System.out.println("A1: "+java.util.Arrays.toString(A1));
      LL1.get(0).v*=10f;
      LL1.set(1,new Wrap_f(LL1.get(1).v+3));  
      System.out.println("LL1: "+LL1);
      System.out.println("A1: "+java.util.Arrays.toString(A1));
      System.out.println();
   }
/*
 --- test3: mutable object  ----
LL1: [10.1, 10.2, 10.3]
A1: [10.1, 10.2, 10.3]
LL1: [101.0, 13.2, 10.3]
A1: [101.0, 10.2, 10.3]
*/

   public static void main(String[] dummy) {
      test1();
      test2();
      test3();
   }

}
