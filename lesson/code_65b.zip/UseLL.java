import java.util.List;
import java.util.LinkedList;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.ListIterator;


public class UseLL {

 //------------------------------------------


   static void copy23_LL() {
      System.out.println("\n --- copy23_LL() --- ");
      final int size=6;
      var L1= new LinkedList<Integer>();
      for(int i=0; i<size; i++) {
         L1.add(i);
      }
      System.out.println("L1: "+L1);

      var L2= new LinkedList<Integer>();
      Iterator<Integer> itr;
      itr= L1.iterator();
      while(itr.hasNext()) {
         Integer x= itr.next(); 
         L2.add(x);
         L2.add(x);
      } 
      System.out.println("L2: "+L2);

      var L3= new LinkedList<Integer>();
      for(int i=0; i<3; i++) {
         itr= L1.iterator();
         while(itr.hasNext()) {
            Integer x= itr.next(); 
            L3.add(x);
         } 
      }
      System.out.println("L3: "+L3);
   }
/*
 --- copy23_LL() ---
L1: [0, 1, 2, 3, 4, 5]
L2: [0, 0, 1, 1, 2, 2, 3, 3, 4, 4, 5, 5]
L3: [0, 1, 2, 3, 4, 5, 0, 1, 2, 3, 4, 5, 0, 1, 2, 3, 4, 5]
*/

   static void sum_LL() {
      System.out.println("\n --- sum_LL() --- ");
      Integer[] a1={10, 20, 30, 40, 50, 60, 70, 80};
      var L1= new LinkedList<Integer>(List.of(a1));
      System.out.println("L1: "+L1);

      int ans=0;
      Iterator<Integer> itr= L1.iterator();
      while(itr.hasNext()) {
         ans+= (int)itr.next(); 
      }
      System.out.println("sum="+ans);
   }
/*
 --- sum_LL() ---
L1: [10, 20, 30, 40, 50, 60, 70, 80]
sum=360
*/

   static void swapContent_LL() {
      System.out.println("\n --- swapContent_LL() --- ");
      var L1= new LinkedList<Integer>(
                 List.of(11,12,13,14,15,16,17)
              );
      var L2= new LinkedList<Integer>(
                 List.of(21,22,23,24,25,26,27)
              );
      System.out.println("L1: "+L1);
      System.out.println("L2: "+L2);

      ListIterator<Integer> itr1= L1.listIterator();
      ListIterator<Integer> itr2= L2.listIterator();
      while(itr1.hasNext()) {
         Integer x1= itr1.next();  Integer x2= itr2.next();
         itr1.set(x2);  itr2.set(x1);
      }
      System.out.println("swapContent...");
      System.out.println("L1: "+L1);
      System.out.println("L2: "+L2);
   }
/*
 --- swapContent_LL() ---
L1: [11, 12, 13, 14, 15, 16, 17]
L2: [21, 22, 23, 24, 25, 26, 27]
swapContent...
L1: [21, 22, 23, 24, 25, 26, 27]
L2: [11, 12, 13, 14, 15, 16, 17]
*/

   static <E> void revert_1(LinkedList<E> L) {
      final int S= L.size();
      final int swap= S/2;  // 7-->3,  6-->3, 1--> 0,  0--> 0  
      ListIterator<E> itr1= L.listIterator();
      ListIterator<E> itr2= L.listIterator(S);
      for(int i=1; i<=swap; i++) {
         E x1= itr1.next();   E x2= itr2.previous();
         itr1.set(x2);        itr2.set(x1);
      }
   }

   static <E> void revert_2(LinkedList<E> L) {
      ListIterator<E> itr1= L.listIterator();
      ListIterator<E> itr2= L.listIterator(L.size());
      while(itr1.nextIndex()<itr2.previousIndex()) {
         E x1= itr1.next();   E x2= itr2.previous();
         itr1.set(x2);        itr2.set(x1);
      }
   }

   static <E> void revert(LinkedList<E> L) {
    revert_1(L);
   // revert_2(L);
   }

   static void test_revert_LL() {
      System.out.println("\n --- test_revert_LL --- ");
      var L1= new LinkedList<Integer>(
                 List.of(11,12,13,14,15,16,17)
              );
      System.out.println("L1: "+L1);
      revert(L1);
      System.out.println("--> "+L1);

      var L2= new LinkedList<Integer>(
                 List.of(11,12,13,14,15,16)
              );
      System.out.println("L2: "+L2);
      revert(L2);
      System.out.println("--> "+L2);
   }
/*
 --- test_revert_LL ---
L1: [11, 12, 13, 14, 15, 16, 17]
--> [17, 16, 15, 14, 13, 12, 11]
L2: [11, 12, 13, 14, 15, 16]
--> [16, 15, 14, 13, 12, 11]
*/

   static <E> LinkedList<E> reverse(LinkedList<E> L) {
      var ans= new LinkedList<E>();
      var itr1= L.listIterator(L.size());
      while(itr1.hasPrevious()) {
         ans.add(itr1.previous());
      }
      return ans;
   }

   static void test_reverse_LL() {
      System.out.println("\n --- test_reverse_LL() --- ");
      var L1= new LinkedList<Integer>(
                 List.of(11,12,13,14,15,16,17)
              );
      System.out.println("L1: "+L1);

      var aux= reverse(L1);
      L1.clear();
      L1.addAll(aux);
      System.out.println("--> "+L1);
   }
/*
 --- test_reverse_LL() ---
L1: [11, 12, 13, 14, 15, 16, 17]
--> [17, 16, 15, 14, 13, 12, 11]
*/

   static void allM10_LL() {
      System.out.println("\n --- allM10_LL() --- ");
      Float[] A1= {  5.0f, 5.1f, 5.2f, 5.3f, 5.4f };
      var L1= new LinkedList<Float>( List.of(A1) );
      System.out.println("L1: "+L1);
   // allM10(L1);
      var itr= L1.listIterator();
      while(itr.hasNext()) {
         Float x= itr.next();
         itr.set(x*10f);
      } 

      System.out.println("L1: "+L1);
   }
/*
 --- allM10_LL() ---
L1: [5.0, 5.1, 5.2, 5.3, 5.4]
L1: [50.0, 51.0, 52.0, 53.0, 54.0]
*/

   static <E> void ROR_asArray(LinkedList<E> L) {
   // simulate the algorithm of ROR in array
      int s= L.size(); 
      if(s<=0) return;      
      var getI= L.listIterator(s);
      var setI= L.listIterator(s);
      E last= getI.previous();        
      while(getI.hasPrevious()) { 
         setI.previous(); // prepare setting-position
         setI.set(getI.previous());
      } 
      setI.previous(); // prepare setting-position
      setI.set(last);
   }
   static <E> void ROR_asDLList(LinkedList<E> L) {
      if(L.isEmpty()) return;      
      L.addFirst(L.removeLast());
   }
   static void test_ROR_LL() {
      System.out.println("\n --- test_ROR_LL() --- ");
      Float[] A1= {  5.0f, 5.1f, 5.2f, 5.3f, 5.4f };
      var L1= new LinkedList<Float>( List.of(A1) );
      System.out.println("L1: "+L1);
      UseLL.<Float>ROR_asArray(L1);
   // ROR_asArray(L1);
      System.out.println("--> "+L1);
      UseLL.<Float>ROR_asDLList(L1);
      System.out.println("--> "+L1);
   }
/*
 --- test_ROR_LL() ---
L1: [5.0, 5.1, 5.2, 5.3, 5.4]
--> [5.4, 5.0, 5.1, 5.2, 5.3]
--> [5.3, 5.4, 5.0, 5.1, 5.2]
*/

   public static void main(String[] dummy) {
      copy23_LL();
      sum_LL();
      swapContent_LL(); 
      test_revert_LL();
      test_reverse_LL();
      allM10_LL();
      test_ROR_LL();
      System.out.println("\n all OK");
   }

}