import java.util.Arrays;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;


// Test Array FromTo
public class TestLL_frAL_toAL {

  static void test1() {
      System.out.println("\n --- test1: ArrayList to LinkedList  ----");
      Wrap_f[] A0= { 
         new Wrap_f(10.1f), new Wrap_f(10.2f), new Wrap_f(10.3f)
      };
      var AL1= 
         new ArrayList<Wrap_f>(List.of(A0));
      System.out.println("AL1: "+AL1
                         +" ( "+AL1.getClass()+" ) ");
      var LL1= 
         new LinkedList<Wrap_f>(AL1);
      System.out.println("LL1: "+LL1+" ( "+LL1.getClass()+" ) ");
   } 
/*
 --- test1: ArrayList to LinkedList  ----
AL1: [10.1, 10.2, 10.3] ( class java.util.ArrayList )
LL1: [10.1, 10.2, 10.3] ( class java.util.LinkedList )
*/


  static void test2() {
      System.out.println("\n --- test2: LinkedList to ArrayList  ----");
      Wrap_f[] A0= { 
         new Wrap_f(10.1f), new Wrap_f(10.2f), new Wrap_f(10.3f)
      };
   // LinkedList<Wrap_f> LL1= 
      var LL1=  
         new LinkedList<Wrap_f>();
      for(int i=0; i<A0.length; i++) {
         LL1.add(A0[i]);
      }  
      System.out.println("LL1: "+LL1+" ( "+ LL1.getClass()+" ) ");

      ArrayList<Wrap_f> AL1= new ArrayList<Wrap_f>(LL1);
      System.out.println("AL1: "+AL1
                           +" ( "+AL1.getClass()+" ) ");
  }
/*
 --- test2: LinkedList to ArrayList  ----
LL1: [10.1, 10.2, 10.3] ( class java.util.LinkedList )
AL1: [10.1, 10.2, 10.3] ( class java.util.ArrayList )
*/

   public static void main(String[] dummy) {
      test1();
      test2();
   }

}
