import java.util.List;
import java.util.LinkedList;
import java.util.function.Predicate;
import java.util.Collection;


// structure test
public class TestLL_restruct_itr {

// public boolean add(E e)
// public void add(int idx, E elm)  must 0<=idx<=this.size()
// public boolean addAll(Collection<? extends E> c)
// public boolean addAll(int idx, Collection<? extends E> c)
/*
   static void test1() {  
      System.out.println("\n --- test1: add, addAll  ----");
      var L= List.of("aaa", "b", "cc");  // return type: List<String>
      var AL1= new ArrayList<String>(); // return type: ArrayList<String>
      AL1.addAll(L);
      System.out.println(AL1);
      try{
         AL1.add(4, "Z1");
      } catch(java.lang.IndexOutOfBoundsException xpt) {
         System.out.println("catch: "+xpt); 
      } 
      AL1.add("Z1");
      System.out.println(AL1);
      AL1.add(1, "Z2");
      System.out.println(AL1);
      AL1.addAll(2, List.of("Z3", "Z4", "Z5"));
      System.out.println(AL1);
   } 
*/
   static void test1_itr() {
      System.out.println("\n --- test1_itr: add, addAll  ----");
      var L= List.of("aaa", "b", "cc");  // return type: List<String>
      var LL1= new LinkedList<String>(); // return type: LinkedList<String>
      LL1.addAll(L);
      System.out.println(LL1);
      try{
         LL1.add(4, "Z1");
      } catch(java.lang.IndexOutOfBoundsException xpt) {
         System.out.println("catch: "+xpt); 
      } 
      LL1.add("Z1");
      System.out.println(LL1);

   // LL1.add(1, "Z2");
      var itr= LL1.listIterator();
      itr.next();  itr.add("Z2");
      System.out.println(LL1);
   // LL1.addAll(2, List.of("Z3", "Z4", "Z5"));
      itr.add("Z3");  itr.add("Z4");  itr.add("Z5");
      System.out.println(LL1);
   } 
/*
 --- test1_itr: add, addAll  ----
[aaa, b, cc]
catch: java.lang.IndexOutOfBoundsException: Index: 4, Size: 3
[aaa, b, cc, Z1]
[aaa, Z2, b, cc, Z1]
[aaa, Z2, Z3, Z4, Z5, b, cc, Z1]
*/

//-------------------------------------------------
// public void clear()
// public E remove(int idx), 
//     return the element removed from the list
// public boolean remove(Object o)
//     Return true if this list contained the specified element

   public static <E> 
   E my_remove(LinkedList<E> LL, int idx) {
      final int sz= LL.size();
      if(! (0<=idx && idx<sz) ) {
         throw new IndexOutOfBoundsException(
                  "(index: "+idx+", size: "+sz+")"
               );
      } 
      E ans;
      if(idx < (sz/2) ) {
         var itr= LL.listIterator();
         while(itr.nextIndex()<idx) {  itr.next();  }
         ans= itr.next();   itr.remove();
      }     
      else {
         var itr= LL.listIterator(sz);
         while(idx<itr.previousIndex()) {  itr.previous();  }
         ans= itr.previous();   itr.remove();
      } 
      return ans; 
   }

   static void test2_itr() {
      System.out.println("\n --- test2_itr  ----");
      var L= List.<Float>of(10f, 11f, 12f, 13f, 14f);
      var LL1= new LinkedList<Float>(L);
      System.out.println("begin: "+LL1);
      Float elm= my_remove(LL1, 0);
      System.out.println("after remove(0): "+LL1);
      System.out.println("removed element: "+elm);
   try{ 
   // Float elm1= LL1.remove(5);
      Float elm1= my_remove(LL1,5);
   }
   catch(IndexOutOfBoundsException xpt) {
      System.out.println("catch: "+xpt); 
   }
      LL1.clear();
      System.out.println("after clear(): "+LL1);
      System.out.println("isEmpty: "+LL1.isEmpty());
   }
/*
 --- test2_itr  ----
begin: [10.0, 11.0, 12.0, 13.0, 14.0]
after remove(0): [11.0, 12.0, 13.0, 14.0]
removed element: 10.0
catch: java.lang.IndexOutOfBoundsException: (index: 5, size: 4)
after clear(): []
isEmpty: true
*/

//-------------------------------------------------
// protected void removeRange(int fromIdx, int toIdx)
// public List<E> subList(int fromIdx, int toIdx) 
//     Returns a view of the portion of this list 

   public static <E> void my_removeRange(
      LinkedList<E> LL, int frI, int toI
   ) {
      final int sz= LL.size();
      if(! (0<=frI && frI<sz && toI<=sz && frI<=toI ) ) {
         throw new IndexOutOfBoundsException(
                  "(frI: "+frI+", toI: "+toI+" size: "+sz+")"
               );
      } 
      final int delSize= toI-frI;   // 3-1=2; 
      var itr= LL.listIterator();  // Iterator no nextIndex()
      while(itr.nextIndex()<frI) {  itr.next(); }
      for(int i=1; i<=delSize; i++) {
         itr.next();  itr.remove();
      }
   }

   static void test2A_itr() {
      System.out.println("\n --- test2A_itr  ----");
      var L= List.<Float>of(10f, 11f, 12f, 13f, 14f);
      var LL1= new LinkedList<Float>(L);
      System.out.println("begin: "+LL1);
   // List<Float> r= LL1.subList(1,3); // a view of LL1
   // r.clear();
      my_removeRange(LL1, 1, 3);      
   // MyLinkedList.removeRange(LL1, 1, 3);      
      System.out.println("after removeRange(1,3): "+LL1);
   }
/*
 --- test2A_itr  ----
begin: [10.0, 11.0, 12.0, 13.0, 14.0]
after removeRange(1,3): [10.0, 13.0, 14.0]
*/


//-------------------------------------------------
// public boolean remove(Object obj)  只刪最前一格
// public boolean removeAll(Collection<?> c)
//    Returns: true if this list changed as a result of the call
// public boolean retainAll(Collection<?> c)
//    Returns: true if this list changed as a result of the call
// in java.util.Collection, boolean contains(Object o)

   public static <E> 
   boolean my_remove(LinkedList<E> LL, Object obj) {
      var itr= LL.listIterator();
      while(itr.hasNext()) {
         E x= itr.next(); 
         if(x.equals(obj)) {
            itr.remove();  return true; 
         }  
      }
      return false;
   }

   public static <E> 
   boolean my_removeAll(
      LinkedList<E> LL, java.util.Collection<?> coll
   ) {
      boolean changed= false;
      var itr= LL.listIterator();
      while(itr.hasNext()) {
         E x= itr.next();
         if(coll.contains(x)) { 
            itr.remove();  changed= true;
         }
      }
      return changed;
   }

   public static <E> 
   boolean my_retainAll(
      LinkedList<E> LL, java.util.Collection<?> coll
   ) {
      boolean changed= false;
      var itr= LL.listIterator();
      while(itr.hasNext()) {
         E x= itr.next();
     //D System.out.print("@"+x);
         if(! coll.contains(x)) { 
     //D System.out.println(" toD");
            itr.remove();  changed= true;
         }
      }
      return changed;
   }

   static void test3_itr() {
      System.out.println(
         "\n --- test3_itr: remove(Object), removeAll, retainAll  ----"
      );
      Float[] A= {10f, 11f, 12f, 13f, 14f, 12f};  // auto box
      var S= List.of(new Float[]{9f, 11f, 13f, 15f}); 
      System.out.println("S: "+S);
      System.out.println("---");

      var LL0= new LinkedList<Float>(List.<Float>of(A));
      System.out.println("begin: "+LL0);
   // LL0.remove(Float.valueOf(12f));
      my_remove(LL0, Float.valueOf(12f));
   // MyLinkedList.remove(LL0, Float.valueOf(12f));
      System.out.println("after remove((Float)12f): "+LL0);
      System.out.println("---");

      var LL1= new LinkedList<Float>(List.of(A));
      System.out.println("begin: "+LL1);
   // LL1.removeAll(S);
      my_removeAll(LL1, S);
   // MyLinkedList.removeAll(LL1, S);
      System.out.println("after removeAll(S): "+LL1);
      System.out.println("---");

      var LL2= new LinkedList<Float>(List.of(A));
      System.out.println("begin: "+LL2);
   // LL2.retainAll(S);
      my_retainAll(LL2, S);
   // MyLinkedList.retainAll(LL2, S);
      System.out.println("after retainAll(S): "+LL2);
   }
/*
 --- test3_itr: remove(Object), removeAll, retainAll  ----
S: [9.0, 11.0, 13.0, 15.0]
---
begin: [10.0, 11.0, 12.0, 13.0, 14.0, 12.0]
after remove((Float)12f): [10.0, 11.0, 13.0, 14.0, 12.0]
---
begin: [10.0, 11.0, 12.0, 13.0, 14.0, 12.0]
after removeAll(S): [10.0, 12.0, 14.0, 12.0]
---
begin: [10.0, 11.0, 12.0, 13.0, 14.0, 12.0]
after retainAll(S): [11.0, 13.0]
*/

   static void test3A_fail_itr() {
      System.out.println("\n --- test3A_fail_itr: remove(Object), removeAll, retainAll  ----");
      Wrap_f[] A= {
         new Wrap_f(10f), new Wrap_f(11f), new Wrap_f(12f),
         new Wrap_f(13f), new Wrap_f(14f), new Wrap_f(12f)
      }; 
      var S= List.of(new Wrap_f(9f), new Wrap_f(11f), 
                     new Wrap_f(13f), new Wrap_f(15f)); 
      System.out.println("S: "+S);
      System.out.println("---");

      var LL0= new LinkedList<Wrap_f>(List.<Wrap_f>of(A));
      System.out.println("begin: "+LL0);
      my_remove(LL0, new Wrap_f(12f));
   // MyLinkedList.remove(LL0, new Wrap_f(12f));
      System.out.println("after remove(new Wrap_f(12f)): "+LL0);
      System.out.println("---");

      var LL1= new LinkedList<Wrap_f>(List.of(A));
      System.out.println("begin: "+LL1);
      my_removeAll(LL1, S);
   // MyLinkedList.removeAll(LL1, S);
      System.out.println("after removeAll(S): "+LL1);
      System.out.println("---");

      var LL2= new LinkedList<Wrap_f>(List.of(A));
      System.out.println("begin: "+LL2);
      my_retainAll(LL2, S);
   // MyLinkedList.retainAll(LL2, S);
      System.out.println("after retainAll(S): "+LL2);
   }
/*
 --- test3A_fail_itr: remove(Object), removeAll, retainAll  ----
S: [9.0, 11.0, 13.0, 15.0]
---
begin: [10.0, 11.0, 12.0, 13.0, 14.0, 12.0]
after remove(new Wrap_f(12f)): [10.0, 11.0, 12.0, 13.0, 14.0, 12.0]
---
begin: [10.0, 11.0, 12.0, 13.0, 14.0, 12.0]
after removeAll(S): [10.0, 11.0, 12.0, 13.0, 14.0, 12.0]
---
begin: [10.0, 11.0, 12.0, 13.0, 14.0, 12.0]
after retainAll(S): []
*/

  static void test3B_itr() {
      System.out.println("\n --- test3B_itr: remove(Object), removeAll, retainAll  ----");
      WrapE_f[] A= {
         new WrapE_f(10f), new WrapE_f(11f), new WrapE_f(12f),
         new WrapE_f(13f), new WrapE_f(14f), new WrapE_f(12f)
      }; 
      var S= List.of(new WrapE_f(9f), new WrapE_f(11f), 
                     new WrapE_f(13f), new WrapE_f(15f)); 
      System.out.println("S: "+S);
      System.out.println("---");

      var LL0= new LinkedList<WrapE_f>(List.<WrapE_f>of(A));
      System.out.println("begin: "+LL0);
      my_remove(LL0, new WrapE_f(12f));
   // MyLinkedList.remove(LL0, new WrapE_f(12f));
      System.out.println("after remove(new WrapE_f(12f)): "+LL0);
      System.out.println("---");

      var LL1= new LinkedList<WrapE_f>(List.of(A));
      System.out.println("begin: "+LL1);
      my_removeAll(LL1, S);
   // MyLinkedList.removeAll(LL1, S);
      System.out.println("after removeAll(S): "+LL1);
      System.out.println("---");

      var LL2= new LinkedList<WrapE_f>(List.of(A));
      System.out.println("begin: "+LL2);
      my_retainAll(LL2, S);
   // MyLinkedList.retainAll(LL2, S);
      System.out.println("after retainAll(S): "+LL2);
   }
/*
 --- test3B_itr: remove(Object), removeAll, retainAll  ----
S: [9.0, 11.0, 13.0, 15.0]
---
begin: [10.0, 11.0, 12.0, 13.0, 14.0, 12.0]
after remove(new WrapE_f(12f)): [10.0, 11.0, 13.0, 14.0, 12.0]
---
begin: [10.0, 11.0, 12.0, 13.0, 14.0, 12.0]
after removeAll(S): [10.0, 12.0, 14.0, 12.0]
---
begin: [10.0, 11.0, 12.0, 13.0, 14.0, 12.0]
after retainAll(S): [11.0, 13.0]
*/

//-------------------------------------------------
   public static void main(String[] dummy){
      test1_itr();

      test2_itr();  
      test2A_itr();

      test3_itr();
      test3A_fail_itr();
      test3B_itr();
   }

}
