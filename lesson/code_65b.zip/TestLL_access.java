import java.util.List;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.function.Predicate;

// access test
public class TestLL_access {

// in class LinkedList<E>
// public E get(int idx) 
// public E set(int idx, E elm)

   static void test1() {
      System.out.println("\n --- test1: on Float  ----");
      Float[] A1= { 10f, 11f, 12f, 13f, 14f };  // auto box
   // LinkedList<Float> LL1= 
      var LL1= 
      // new LinkedList<Float>(List.<Float>of(A1));
         new LinkedList<Float>(List.of(A1));
      System.out.println("LL1: "+LL1);
      for(int i=0; i<LL1.size(); i++) {
         System.out.print(LL1.get(i)+", ");
      } 
      System.out.println();
      System.out.println("A1: "+Arrays.toString(A1));

      for(int i=0; i<LL1.size(); i++) {
         LL1.set(i, LL1.get(i)*10);
      } 
      System.out.println("after set*10,\nAL1: "+LL1);
      System.out.println("A1: "+Arrays.toString(A1));
   } 
/*
 --- test1: on Float  ----
AL1: [10.0, 11.0, 12.0, 13.0, 14.0]
10.0, 11.0, 12.0, 13.0, 14.0,
A1: [10.0, 11.0, 12.0, 13.0, 14.0]
after set*10,
AL1: [100.0, 110.0, 120.0, 130.0, 140.0]
A1: [10.0, 11.0, 12.0, 13.0, 14.0]
*/

   static void test2() {
      System.out.println("\n --- test2: on Wrap_f  ----");

      Wrap_f[] A2= { 
         new Wrap_f(10f), new Wrap_f(11f), 
         new Wrap_f(12f), new Wrap_f(13f), 
      };  
   // LinkedList<Wrap_f> LL2= 
      var LL2= 
      // new LinkedList<Wrap_f>(List.<Wrap_f>of(A2));
         new LinkedList<Wrap_f>(List.of(A2));
      System.out.println("LL2: "+LL2);
      System.out.println("A2: "+Arrays.toString(A2));

      for(int i=0; i<LL2.size(); i++) {
         LL2.get(i).v*=2;
      } 
      System.out.println("after *=2,\nAL2: "+LL2);
      System.out.println("A2: "+Arrays.toString(A2));
   } 
/*
 --- test2: on Wrap_f  ----
AL2: [10.0, 11.0, 12.0, 13.0]
A2: [10.0, 11.0, 12.0, 13.0]
after *=2,
AL2: [20.0, 22.0, 24.0, 26.0]
A2: [20.0, 22.0, 24.0, 26.0]
*/


// public boolean contains(Object o)
//    Returns: true if this list contains the specified element
// public int indexOf(Object o)
//    Returns: the index of the first occurrence of the specified element 
//             or -1 if this list does not contain the element
// public int lastIndexOf(Object o)
//    Returns: the index of the last occurrence of the specified element in this list 
//             or -1 if this list does not contain the element

   static void test3() {
      System.out.println("\n --- test3: search  ----");
      Float[] A1= { 10f, 11f, 12f, 13f };  // auto box
   // LinkedList<Float> LL1= 
      var LL1= 
      // new LinkedList<Float>(List.<Float>of(A1));
         new LinkedList<Float>(List.of(A1));
      System.out.println("LL1: "+LL1);
      System.out.println("LL1.contains(9f): "
                         +LL1.contains(Float.valueOf(9f)));
      System.out.println("LL1.contains(12f): "
                         +LL1.contains(Float.valueOf(12f)));
    //LL1.add(Float.valueOf(12f));
      LL1.add(12f);
      System.out.println("after add(12f),\nAL1: "+LL1);
      System.out.println("LL1.indexOf(9f): "
                         +LL1.indexOf(Float.valueOf(9f)));
      System.out.println("LL1.indexOf(12f): "
                         +LL1.indexOf(Float.valueOf(12f)));
      System.out.println("LL1.lastIndexOf(9f): "
                         +LL1.lastIndexOf(Float.valueOf(9f)));
      System.out.println("LL1.lastIndexOf(12f): "
                         +LL1.lastIndexOf(Float.valueOf(12f)));
      System.out.println();
   }
/*
 --- test3: search  ----
AL1: [10.0, 11.0, 12.0, 13.0]
AL1.contains(9f): false
AL1.contains(12f): true
after add(12f),
AL1: [10.0, 11.0, 12.0, 13.0, 12.0]
AL1.indexOf(9f): -1
AL1.indexOf(12f): 2
AL1.lastIndexOf(9f): -1
AL1.lastIndexOf(12f): 4
*/

   static void test4_fail() {
      System.out.println("\n --- test4_fail: search on Wrap_f ----");
      Wrap_f[] A1= { 
         new Wrap_f(10f), new Wrap_f(11f), 
         new Wrap_f(12f), new Wrap_f(13f) 
      };  
      var LL1= 
         new LinkedList<Wrap_f>(List.of(A1));
      System.out.println("LL1: "+LL1);
      System.out.println("LL1.contains(9f): "
                         +LL1.contains(new Wrap_f(9f)));
      System.out.println("LL1.contains(12f): "
                         +LL1.contains(new Wrap_f(12f)));
      LL1.add(new Wrap_f(12f));
      System.out.println("after add(12f),\nAL1: "+LL1);
      System.out.println("LL1.indexOf(9f): "
                         +LL1.indexOf(new Wrap_f(9f)));
      System.out.println("LL1.indexOf(12f): "
                         +LL1.indexOf(new Wrap_f(12f)));
      System.out.println("LL1.lastIndexOf(9f): "
                         +LL1.lastIndexOf(new Wrap_f(9f)));
      System.out.println("LL1.lastIndexOf(12f): "
                         +LL1.lastIndexOf(new Wrap_f(12f)));
      System.out.println();
   }
/*
 --- test4_fail: search on Wrap_f ----
LL1: [10.0, 11.0, 12.0, 13.0]
LL1.contains(9f): false
LL1.contains(12f): false
after add(12f),
AL1: [10.0, 11.0, 12.0, 13.0, 12.0]
LL1.indexOf(9f): -1
LL1.indexOf(12f): -1
LL1.lastIndexOf(9f): -1
LL1.lastIndexOf(12f): -1
*/

   static void test5() {
      System.out.println("\n --- test5: search on WrapE_f ----");
      WrapE_f[] A1= { 
         new WrapE_f(10f), new WrapE_f(11f), 
         new WrapE_f(12f), new WrapE_f(13f) 
      };  
      var LL1= 
         new LinkedList<WrapE_f>(List.of(A1));
      System.out.println("LL1: "+LL1);
      System.out.println("LL1.contains(9f): "
                         +LL1.contains(new WrapE_f(9f)));
      System.out.println("LL1.contains(12f): "
                         +LL1.contains(new WrapE_f(12f)));
      LL1.add(new WrapE_f(12f));
      System.out.println("after add(12f),\nAL1: "+LL1);
      System.out.println("LL1.indexOf(9f): "
                         +LL1.indexOf(new WrapE_f(9f)));
      System.out.println("LL1.indexOf(12f): "
                         +LL1.indexOf(new WrapE_f(12f)));
      System.out.println("LL1.lastIndexOf(9f): "
                         +LL1.lastIndexOf(new WrapE_f(9f)));
      System.out.println("LL1.lastIndexOf(12f): "
                         +LL1.lastIndexOf(new WrapE_f(12f)));
      System.out.println();
   }
/*
 --- test5: search on WrapE_f ----
LL1: [10.0, 11.0, 12.0, 13.0]
LL1.contains(9f): false
LL1.contains(12f): true
after add(12f),
AL1: [10.0, 11.0, 12.0, 13.0, 12.0]
LL1.indexOf(9f): -1
LL1.indexOf(12f): 2
LL1.lastIndexOf(9f): -1
LL1.lastIndexOf(12f): 4
*/

   public static void main(String[] dummy){
      test1();
      test2();
      test3();
      test4_fail(); // Wrap_f do not override equals(Object)
      test5();
   }

}
