import java.util.List;
import java.util.Arrays;
import java.util.Iterator;
import java.util.ListIterator;
import java.util.LinkedList;
import java.util.function.Predicate;

// access test
public class TestLL_access_itr {

// in class LinkedList<E>
// public E get(int idx) 
// public E set(int idx, E elm)

   static void test1() {
      System.out.println("\n --- test1: on Float  ----");
      Float[] A1= { 10f, 11f, 12f, 13f, 14f };  // auto box
   // LinkedList<Float> LL1= 
      var LL1= 
      // new LinkedList<Float>(List.<Float>of(A1));
         new LinkedList<Float>(List.of(A1));
      System.out.println("LL1: "+LL1);
      for(int i=0; i<LL1.size(); i++) {
         System.out.print(LL1.get(i)+", ");
      // System.out.print(MyLinkedList.get(LL1, i)+", ");
      } 
      System.out.println();
      System.out.println("A1: "+Arrays.toString(A1));

      for(int i=0; i<LL1.size(); i++) {
         LL1.set(i, LL1.get(i)*10);
      // MyLinkedList.set(LL1, i, MyLinkedList.get(LL1, i)*10);
      } 
      System.out.println("after set*10,\nLL1: "+LL1);
      System.out.println("A1: "+Arrays.toString(A1));
   } 
/*
 --- test1: on Float  ----
LL1: [10.0, 11.0, 12.0, 13.0, 14.0]
10.0, 11.0, 12.0, 13.0, 14.0,
A1: [10.0, 11.0, 12.0, 13.0, 14.0]
after set*10,
LL1: [100.0, 110.0, 120.0, 130.0, 140.0]
A1: [10.0, 11.0, 12.0, 13.0, 14.0]
*/

   static void test1_itr() {
      System.out.println("\n --- test1_itr: on Float  ----");
      Float[] A1= { 10f, 11f, 12f, 13f, 14f };  // auto box
   // LinkedList<Float> LL1= 
      var LL1= 
      // new LinkedList<Float>(List.<Float>of(A1));
         new LinkedList<Float>(List.of(A1));
      System.out.println("LL1: "+LL1);
      for(Iterator<Float> itr= LL1.iterator(); 
          itr.hasNext();     ) 
      {
         System.out.print(itr.next()+", ");
      } 
      System.out.println();
      System.out.println("A1: "+Arrays.toString(A1));

      for(ListIterator<Float> itr= LL1.listIterator(); 
          itr.hasNext();     ) 
      {
         Float x= itr.next()*10;
         itr.set(x);
      } 
      System.out.println("after set*10,\nLL1: "+LL1);
      System.out.println("A1: "+Arrays.toString(A1));
   } 
/*
 --- test1_itr: on Float  ----
LL1: [10.0, 11.0, 12.0, 13.0, 14.0]
10.0, 11.0, 12.0, 13.0, 14.0,
A1: [10.0, 11.0, 12.0, 13.0, 14.0]
after set*10,
LL1: [100.0, 110.0, 120.0, 130.0, 140.0]
A1: [10.0, 11.0, 12.0, 13.0, 14.0]
*/

   static void test2() {
      System.out.println("\n --- test2: on Wrap_f  ----");

      Wrap_f[] A2= { 
         new Wrap_f(10f), new Wrap_f(11f), 
         new Wrap_f(12f), new Wrap_f(13f), 
      };  
   // LinkedList<Wrap_f> LL2= 
      var LL2= 
      // new LinkedList<Wrap_f>(List.<Wrap_f>of(A2));
         new LinkedList<Wrap_f>(List.of(A2));
      System.out.println("LL2: "+LL2);
      System.out.println("A2: "+Arrays.toString(A2));

      for(int i=0; i<LL2.size(); i++) {
         LL2.get(i).v*=2;
      // MyLinkedList.get(LL2,i).v*=2;
      } 
      System.out.println("after *=2,\nAL2: "+LL2);
      System.out.println("A2: "+Arrays.toString(A2));
   } 
/*
 --- test2: on Wrap_f  ----
LL2: [10.0, 11.0, 12.0, 13.0]
A2: [10.0, 11.0, 12.0, 13.0]
after *=2,
AL2: [20.0, 22.0, 24.0, 26.0]
A2: [20.0, 22.0, 24.0, 26.0]
*/

   static void test2_itr() {
      System.out.println("\n --- test2_itr: on Wrap_f  ----");

      Wrap_f[] A2= { 
         new Wrap_f(10f), new Wrap_f(11f), 
         new Wrap_f(12f), new Wrap_f(13f), 
      };  
   // LinkedList<Wrap_f> LL2= 
      var LL2= 
      // new LinkedList<Wrap_f>(List.<Wrap_f>of(A2));
         new LinkedList<Wrap_f>(List.of(A2));
      System.out.println("LL2: "+LL2);
      System.out.println("A2: "+Arrays.toString(A2));

      for(Iterator<Wrap_f> itr= LL2.iterator(); 
          itr.hasNext();   ) 
      {
         itr.next().v*=2;
      } 
      System.out.println("after *=2,\nLL2: "+LL2);
      System.out.println("A2: "+Arrays.toString(A2));
   } 
/*
 --- test2_itr: on Wrap_f  ----
LL2: [10.0, 11.0, 12.0, 13.0]
A2: [10.0, 11.0, 12.0, 13.0]
after *=2,
LL2: [20.0, 22.0, 24.0, 26.0]
A2: [20.0, 22.0, 24.0, 26.0]
*/


// public boolean contains(Object o)
//    Returns: true if this list contains the specified element
// public int indexOf(Object o)
//    Returns: the index of the first occurrence of the specified element 
//             or -1 if this list does not contain the element
// public int lastIndexOf(Object o)
//    Returns: the index of the last occurrence of the specified element in this list 
//             or -1 if this list does not contain the element

   static <E> int my_lastIndexOf(LinkedList<E> LL, Object o) {
      var itr= LL.listIterator(LL.size());
      while(itr.hasPrevious()) {
         var x= itr.previous();
         if(x.equals(o)) return itr.nextIndex();
      }
      return -1;  
   }  // copy to class MyLinkedList

   static <E> int my_indexOf(LinkedList<E> LL, Object o) {
   // return LL.indexOf(o);
      var itr= LL.listIterator(0);
      while(itr.hasNext()) {
         var x= itr.next();
         if(x.equals(o)) return itr.previousIndex();
      }
      return -1;  
   } // copy to class MyLinkedList

   static <E> boolean my_contains(LinkedList<E> LL, Object o) {
      return LL.contains(o);
   // exercise: implement this function by yourself 
   } // copy to class MyLinkedList

   static void test3_itr() {
      System.out.println("\n --- test3_itr: search  ----");
      Float[] A1= { 10f, 11f, 12f, 13f };  // auto box
   // LinkedList<Float> LL1= 
      var LL1= 
      // new LinkedList<Float>(List.<Float>of(A1));
         new LinkedList<Float>(List.of(A1));
      System.out.println("LL1: "+LL1);
      System.out.println(
         "LL1.contains(9f): "
      // +my_contains(LL1, Float.valueOf(9f))
         +MyLinkedList.contains(LL1, Float.valueOf(9f))
      );
      System.out.println("LL1.contains(12f): "
                         +my_contains(LL1, Float.valueOf(12f)));
    //LL1.add(Float.valueOf(12f));
      LL1.add(12f);
      System.out.println("after add(12f),\nLL1: "+LL1);
      System.out.println(
         "LL1.indexOf(9f): "
      // +my_indexOf(LL1, Float.valueOf(9f))
         +MyLinkedList.indexOf(LL1, Float.valueOf(9f))
      );
      System.out.println("LL1.indexOf(12f): "
                         +my_indexOf(LL1, Float.valueOf(12f)));
      System.out.println(
         "LL1.lastIndexOf(9f): "
      // +my_lastIndexOf(LL1, Float.valueOf(9f))
         +MyLinkedList.lastIndexOf(LL1, Float.valueOf(9f))
      );
      System.out.println(
         "LL1.lastIndexOf(12f): "
      // +my_lastIndexOf(LL1, Float.valueOf(12f))
         +MyLinkedList.lastIndexOf(LL1, Float.valueOf(12f))
      );
      System.out.println();
   }
/*
 --- test3_itr: search  ----
LL1: [10.0, 11.0, 12.0, 13.0]
LL1.contains(9f): false
LL1.contains(12f): true
after add(12f),
LL1: [10.0, 11.0, 12.0, 13.0, 12.0]
LL1.indexOf(9f): -1
LL1.indexOf(12f): 2
LL1.lastIndexOf(9f): -1
LL1.lastIndexOf(12f): 4
*/

   static void test4fail_itr() {
      System.out.println("\n --- test4_fail: search on Wrap_f ----");
      Wrap_f[] A1= { 
         new Wrap_f(10f), new Wrap_f(11f), 
         new Wrap_f(12f), new Wrap_f(13f) 
      };  
      var LL1= 
         new LinkedList<Wrap_f>(List.of(A1));
      System.out.println("LL1: "+LL1);
      System.out.println(
         "LL1.contains(9f): "
         +my_contains(LL1, new Wrap_f(9f))
      );
      System.out.println(
         "LL1.contains(12f): "
         +my_contains(LL1, new Wrap_f(12f))
      );
    //LL1.add(Float.valueOf(12f));
      LL1.add(new Wrap_f(12f));
      System.out.println("after add(12f),\nLL1: "+LL1);
      System.out.println(
         "LL1.indexOf(9f): "
         +my_indexOf(LL1, new Wrap_f(9f))
      );
      System.out.println(
         "LL1.indexOf(12f): "
         +my_indexOf(LL1, new Wrap_f(12f))
      );
      System.out.println(
         "LL1.lastIndexOf(9f): "
         +my_lastIndexOf(LL1, new Wrap_f(9f))
      );
      System.out.println(
         "LL1.lastIndexOf(12f): "
         +my_lastIndexOf(LL1, new Wrap_f(12f))
      );
      System.out.println();
   }
/*
 --- test4_fail: search on Wrap_f ----
LL1: [10.0, 11.0, 12.0, 13.0]
LL1.contains(9f): false
LL1.contains(12f): false
after add(12f),
LL1: [10.0, 11.0, 12.0, 13.0, 12.0]
LL1.indexOf(9f): -1
LL1.indexOf(12f): -1
LL1.lastIndexOf(9f): -1
LL1.lastIndexOf(12f): -1
*/

   static void test5_itr() {
      System.out.println("\n --- test5: search on WrapE_f ----");
      WrapE_f[] A1= { 
         new WrapE_f(10f), new WrapE_f(11f), 
         new WrapE_f(12f), new WrapE_f(13f) 
      };  
      var LL1= 
         new LinkedList<WrapE_f>(List.of(A1));
      System.out.println("LL1: "+LL1);
      System.out.println(
         "LL1.contains(9f): "
         +my_contains(LL1, new WrapE_f(9f))
      );
      System.out.println(
         "LL1.contains(12f): "
         +my_contains(LL1, new WrapE_f(12f))
      );
    //LL1.add(Float.valueOf(12f));
      LL1.add(new WrapE_f(12f));
      System.out.println("after add(12f),\nLL1: "+LL1);
      System.out.println(
         "LL1.indexOf(9f): "
         +my_indexOf(LL1, new WrapE_f(9f))
      );
      System.out.println(
         "LL1.indexOf(12f): "
         +my_indexOf(LL1, new WrapE_f(12f))
      );
      System.out.println(
         "LL1.lastIndexOf(9f): "
         +my_lastIndexOf(LL1, new WrapE_f(9f))
      );
      System.out.println(
         "LL1.lastIndexOf(12f): "
         +my_lastIndexOf(LL1, new WrapE_f(12f))
      );
      System.out.println();
   }
/*

 --- test5: search on WrapE_f ----
LL1: [10.0, 11.0, 12.0, 13.0]
LL1.contains(9f): false
LL1.contains(12f): true
after add(12f),
LL1: [10.0, 11.0, 12.0, 13.0, 12.0]
LL1.indexOf(9f): -1
LL1.indexOf(12f): 2
LL1.lastIndexOf(9f): -1
LL1.lastIndexOf(12f): 4
*/


   public static void main(String[] dummy){
      test1();
      test1_itr();
      test2();
      test2_itr();
      test3_itr();
      test4fail_itr();
      test5_itr();
   }

}