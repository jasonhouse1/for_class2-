import java.util.LinkedList;
import java.util.List;
import java.util.Arrays;
import java.util.Comparator;

//LwP:  LinkedList::subList create an intervalReference
public class TestLL_subList {

  static void test1() {
      System.out.println("\n --- test1: get, set ----");
      LinkedList<Float> LL1= 
         new LinkedList<Float>(List.of(0.7f, 0.2f, 0.3f, 0.9f, 0.1f)); 
      System.out.println("LL1: "+LL1);
      List<Float> itv= LL1.subList(1,4);
      System.out.println("itv[1,4): "+itv
                         +"("+itv.getClass()+")" );

      System.out.println("... after itv.set(1, itv.get(0)*100)");
      itv.set(1, itv.get(0)*100);
      System.out.println("itv[1,4): "+itv
                         +"("+itv.getClass()+")" );
      System.out.println("LL1: "+LL1);
   }
/*
 --- test1: get, set ----
LL1: [0.7, 0.2, 0.3, 0.9, 0.1]
itv[1,4): [0.2, 0.3, 0.9](class java.util.AbstractList$SubList)
... after itv.set(1, itv.get(0)*100)
itv[1,4): [0.2, 20.0, 0.9](class java.util.AbstractList$SubList)
LL1: [0.7, 0.2, 20.0, 0.9, 0.1]
*/

   static void test2() {
      System.out.println("\n --- test2: add, remove, clear in subList ----");

      LinkedList<Float> LL1= 
         new LinkedList<Float>(List.of(0.7f, 0.2f, 0.3f, 0.9f, 0.1f)); 
      System.out.println("LL1: "+LL1+"("+LL1.getClass()+")");
      List<Float> itv= LL1.subList(1,4);
      System.out.println("itv[1,4): "+itv
                         +"("+itv.getClass()+")" );

      System.out.println("... after itv.add((Float)7.1f)");
      itv.add((Float)7.1f);
      System.out.println("itv[1,4): "+itv
                         +"("+itv.getClass()+")" );
      System.out.println("LL1: "+LL1+"("+LL1.getClass()+")");

      System.out.println("... clone");
  //  LinkedList<Float> cln= (LinkedList<Float>)itv.clone();
               // Error: cannot find method clone() in List<Float> 
      LinkedList<Float> cln= new LinkedList<Float>(itv);
      System.out.println("clone of itv[1,4): "+cln+"("+cln.getClass()+")");

      System.out.println("... after itv.remove(1)");
      itv.remove(1);
      System.out.println("itv[1,4): "+itv
                         +"("+itv.getClass()+")" );
      System.out.println("LL1: "+LL1+"("+LL1.getClass()+")");
      System.out.println("clone of itv[1,4): "+cln+"("+cln.getClass()+")");

      System.out.println("... after itv.clear");
      itv.clear();
      System.out.println("itv[1,4): "+itv
                         +"("+itv.getClass()+")" );
      System.out.println("LL1: "+LL1+"("+LL1.getClass()+")");
      System.out.println("clone of itv[1,4): "+cln+"("+cln.getClass()+")");
   }
/*
 --- test2: add, remove, clear in subList ----
LL1: [0.7, 0.2, 0.3, 0.9, 0.1](class java.util.LinkedList)
itv[1,4): [0.2, 0.3, 0.9](class java.util.AbstractList$SubList)
... after itv.add((Float)7.1f)
itv[1,4): [0.2, 0.3, 0.9, 7.1](class java.util.AbstractList$SubList)
LL1: [0.7, 0.2, 0.3, 0.9, 7.1, 0.1](class java.util.LinkedList)
... clone
clone of itv[1,4): [0.2, 0.3, 0.9, 7.1](class java.util.LinkedList)
... after itv.remove(1)
itv[1,4): [0.2, 0.9, 7.1](class java.util.AbstractList$SubList)
LL1: [0.7, 0.2, 0.9, 7.1, 0.1](class java.util.LinkedList)
clone of itv[1,4): [0.2, 0.3, 0.9, 7.1](class java.util.LinkedList)
... after itv.clear
itv[1,4): [](class java.util.AbstractList$SubList)
LL1: [0.7, 0.1](class java.util.LinkedList)
clone of itv[1,4): [0.2, 0.3, 0.9, 7.1](class java.util.LinkedList)
*/

  static void test3() {
      System.out.println("\n --- test3: sort ----");
      LinkedList<Float> LL1= 
         new LinkedList<Float>(List.of(0.7f, 0.2f, 0.3f, 0.9f, 0.1f)); 
      System.out.println("LL1: "+LL1);
      List<Float> itv= LL1.subList(1,4);
      System.out.println("itv[1,4): "+itv
                         +"("+itv.getClass()+")" );

      System.out.println("... after sort");
      itv.sort(java.util.Comparator.reverseOrder());
      System.out.println("itv[1,4): "+itv
                         +"("+itv.getClass()+")" );
      System.out.println("LL1: "+LL1);
   }
/*
 --- test3: sort ----
LL1: [0.7, 0.2, 0.3, 0.9, 0.1]
itv[1,4): [0.2, 0.3, 0.9](class java.util.AbstractList$SubList)
... after sort
itv[1,4): [0.9, 0.3, 0.2](class java.util.AbstractList$SubList)
LL1: [0.7, 0.9, 0.3, 0.2, 0.1]
*/

  static void test4() {
      System.out.println("\n --- test4: crash ----");
      LinkedList<Float> LL1= 
         new LinkedList<Float>(List.of(0.7f, 0.2f, 0.3f, 0.9f, 0.1f)); 
      System.out.println("LL1: "+LL1);
      List<Float> itv= LL1.subList(1,4);
      System.out.println("itv[1,4): "+itv
                         +"("+itv.getClass()+")" );

      LL1.set(2, 9f);  // OK
      System.out.println("itv: "+itv);  // OK

      LL1.add(0.2f);  // cause itv crash
      try{ 
      itv.get(0);
      }
      catch( java.util.ConcurrentModificationException xpt) {
         System.out.println("catch ConcurrentModificationException");
      } 
      try{ 
      System.out.println("itv: "+itv);
      }
      catch( java.util.ConcurrentModificationException xpt) {
         System.out.println("catch ConcurrentModificationException");
      } 
   }
/*
 --- test4: crash ----
LL1: [0.7, 0.2, 0.3, 0.9, 0.1]
itv[1,4): [0.2, 0.3, 0.9](class java.util.AbstractList$SubList)
itv: [0.2, 9.0, 0.9]
catch ConcurrentModificationException
catch ConcurrentModificationException
*/

   public static void main(String[] dummy){
      test1();
      test2();
      test3();
      test4();
      System.out.println("\n all OK" ); 
   }

}
